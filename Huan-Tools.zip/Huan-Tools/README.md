# Huan-Tools (Viqitos-Tools)

<div align="center">

**一个基于 Shizuku 的 Android 系统工具箱应用**

[![Android](https://img.shields.io/badge/Android-7.0%2B-green.svg)](https://android.com)
[![API](https://img.shields.io/badge/API-24%2B-brightgreen.svg)](https://android.com)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Shizuku](https://img.shields.io/badge/Shizuku-13.1.0-orange.svg)](https://shizuku.rikka.app)

</div>

---

## 项目简介

Huan-Tools 是一款功能强大的 Android 系级工具箱应用，通过 [Shizuku](https://shizuku.rikka.app/) 框架实现**无需 Root 权限**的系统级别操作。采用 Material Design 3 设计语言，为高级用户和开发者提供全面的系统管理和优化功能。

### 核心特性

- 无需 Root 权限，基于 Shizuku 框架实现系统级操作
- Material Design 3 现代化设计
- 支持动态颜色，跟随系统主题
- 完善的卡密验证系统
- 自动更新机制
- 全面的崩溃日志记录
- 流畅的 M3 Expressive 动画

---

## 功能模块

### 1. 应用管理

全面管理设备上已安装的应用程序：

- 应用列表展示（系统应用 / 用户应用）
- 应用搜索和过滤
- 完全卸载 / 保留数据卸载
- 清除应用数据和缓存
- 强制停止应用
- 应用编译优化（多种编译模式）
- 重置编译状态
- 查看应用详细信息
- 进程管理（杀死进程、释放内存）
- 后台数据访问控制
- 取消后台 Job

### 2. 权限管理

查看和管理应用权限使用情况：

- 按应用分组显示权限
- 按权限类型分组显示应用
- 撤销危险权限
- 查看权限授予状态

### 3. 温度查询

实时监控设备温度：

- 查询各传感器温度
- 实时温度变化监控
- 温度过高警告

### 4. 电源信息

详细的电池和电源信息：

- 电池状态查询
- 充电状态查看
- 电池健康度监测
- 剩余电量估算

### 5. 系统优化

一键优化系统性能：

- 清理所有应用缓存
- 优化系统设置项
- 禁用不必要的系统服务
- 性能优化建议

### 6. 日志查看

查看和管理应用日志：

- 查看应用运行日志
- 查看崩溃日志
- 导出日志文件
- 搜索和过滤日志

---

## 技术栈

### 核心框架

| 技术 | 版本 | 说明 |
|------|------|------|
| Shizuku | 13.1.0 | 无需 Root 的系统权限框架 |
| AndroidX | - | 现代 Android 开发框架 |
| Material Design 3 | 1.12.0 | 最新 Material Design 设计语言 |
| Navigation Component | - | 页面导航管理 |
| ViewModel + LiveData | - | 架构组件 |

### UI 库

- **Material Components** - Material Design 3 组件库
- **DialogX** (0.0.50) - 对话框和弹窗库
- **ViewBinding** - 视图绑定

### 网络请求

- **OkHttp** (4.12.0) - HTTP 客户端（更新检查和卡密验证）

### 构建工具

- **Gradle** 8.12.2 - 构建系统
- **Android Gradle Plugin** 8.12.2
- **Version Catalog** - 依赖版本统一管理

---

## 系统要求

### 前置条件

- Android 7.0 (API Level 24) 或更高版本
- 已安装 [Shizuku](https://shizuku.rikka.app/) 应用
- Shizuku 服务运行中

### 应用权限

```xml
<!-- 存储权限（用于旧版本） -->
WRITE_EXTERNAL_STORAGE (maxSdkVersion 28)
READ_EXTERNAL_STORAGE (maxSdkVersion 32)

<!-- 管理所有文件访问权限 -->
MANAGE_EXTERNAL_STORAGE

<!-- 网络权限（用于更新和卡密验证） -->
INTERNET

<!-- 通知权限（Android 13+） -->
POST_NOTIFICATIONS
```

---

## 安装与使用

### 安装步骤

1. **安装 Shizuku**
   - 从 [GitHub Releases](https://github.com/RikkaApps/Shizuku/releases) 或 [Google Play](https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api) 下载 Shizuku
   - 启动 Shizuku 服务（通过 ADB 或无线调试）

2. **安装 Huan-Tools**
   - 下载 APK 文件并安装
   - 首次启动时授予 Shizuku 权限
   - 完成卡密验证

3. **授予权限**
   - 在 Shizuku 应用中授权 Huan-Tools
   - 允许存储和通知权限

### 使用指南

1. **启动应用**
   - 首次启动会进行卡密验证
   - 自动请求 Shizuku 权限

2. **使用工具**
   - 在首页选择需要的工具模块
   - 根据提示进行操作

3. **查看日志**
   - 在设置中可以查看运行日志和崩溃日志

---

## 项目结构

```
app/
├── src/main/java/com/viqitos/tools/
│   ├── MainActivity.java              # 主入口 Activity
│   ├── ViqitosApplication.java        # Application 类
│   ├── ui/                            # UI 层
│   │   ├── home/                      # 首页模块
│   │   ├── settings/                  # 设置模块
│   │   ├── appmanager/                # 应用管理模块
│   │   ├── permission/                # 权限管理模块
│   │   ├── thermal/                   # 温度查询模块
│   │   ├── logs/                      # 日志查看模块
│   │   ├── powerinfo/                 # 电源信息模块
│   │   └── systemoptimize/            # 系统优化模块
│   └── utils/                         # 工具类
│       ├── ShizukuHelper.java         # Shizuku 权限助手
│       ├── CrashHandler.java          # 崩溃日志处理器
│       ├── UpdateManager.java         # 应用更新管理器
│       └── CardVerificationManager.java # 卡密验证管理器
├── src/main/res/                      # 资源文件
│   ├── layout/                        # 布局文件
│   ├── values/                        # 值资源
│   ├── drawable/                      # 图标资源
│   └── xml/                           # XML 配置
└── build.gradle                       # 应用级构建配置
```

---

## 开发指南

### 环境配置

1. **安装 Android Studio**
   - 推荐使用 Android Studio Hedgehog | 2023.1.1 或更高版本

2. **配置 Gradle**
   ```bash
   # 克隆项目
   git clone https://github.com/boxiaolanya2008/Huan-Tools.git
   cd Huan-Tools

   # 使用 Gradle Wrapper 构建
   ./gradlew assembleDebug
   ```

3. **依赖版本**

   查看 `gradle/libs.versions.toml` 获取最新的依赖版本配置。

### 构建说明

#### Debug 版本

```bash
./gradlew assembleDebug
```

#### Release 版本

```bash
./gradlew assembleRelease
```

生成的 APK 文件位于 `app/build/outputs/apk/` 目录。

### 架构设计

本项目采用 **MVVM (Model-View-ViewModel)** 架构模式：

```
┌─────────────────────────────────────────┐
│              UI Layer                   │
│  (Fragment/Activity with ViewBinding)   │
└───────────────┬─────────────────────────┘
                │
                ↓
┌─────────────────────────────────────────┐
│           ViewModel Layer               │
│  (LiveData, State Management)           │
└───────────────┬─────────────────────────┘
                │
                ↓
┌─────────────────────────────────────────┐
│          Utils/Helpers Layer            │
│  (ShizukuHelper, UpdateManager, etc.)   │
└─────────────────────────────────────────┘
```

### 代码规范

- 遵循 [Android Kotlin 编码规范](https://developer.android.com/kotlin/style-guide)
- 使用有意义的变量和函数命名
- 添加必要的注释和文档
- 保持代码简洁和可读性

---

## 核心依赖

### Shizuku 集成

```gradle
implementation "dev.rikka.shizuku:api:13.1.0"
implementation "dev.rikka.shizuku:provider:13.1.0"
```

### Material Design 3

```gradle
implementation "com.google.android.material:material:1.12.0"
```

### 对话框库

```gradle
implementation "com.github.kongzue.DialogX:DialogX:0.0.50"
```

### 网络请求

```gradle
implementation "com.squareup.okhttp3:okhttp:4.12.0"
```

---

## 安全特性

1. **Shizuku Provider** - 通过 Shizuku 框架安全地执行系统命令
2. **FileProvider** - 安全地共享文件（用于 APK 安装）
3. **网络安全配置** - `network_security_config.xml`
4. **崩溃日志记录** - 完整的崩溃处理机制
5. **卡密验证系统** - 应用启动前进行卡密验证

---

## 特色功能

### Material You 动态颜色

Android 12+ 自动应用系统主题色，跟随系统壁纸变化。

### M3 Expressive 动画

- 进入动画
- 按钮按压动画
- 波纹效果
- 缩放动画

### 自动更新

- 支持后台自动检查更新
- 24 小时检查一次
- 显示更新进度
- 支持下载和安装更新

### 卡密验证系统

- 应用启动时强制进行卡密验证
- 验证成功后才加载应用界面
- 防止未授权使用

---

## 常见问题

### Q: 如何启动 Shizuku 服务？

**A:** 有两种方式：
1. 通过 ADB 命令：`adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/files/start.sh`
2. 通过无线调试（Android 11+）

### Q: 应用无法获取 Shizuku 权限怎么办？

**A:** 确保：
- Shizuku 服务正在运行
- 在 Shizuku 应用中已授权 Huan-Tools
- Shizuku 版本不低于 13.1.0

### Q: 为什么需要存储权限？

**A:** 存储权限用于：
- 安装应用更新时下载 APK
- 导出日志文件
- 管理应用缓存

### Q: 如何禁用自动更新？

**A:** 在设置中关闭「自动检查更新」选项。

---

## 贡献指南

欢迎贡献代码、报告问题或提出建议！

1. Fork 本项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

### 开发规范

- 遵循现有代码风格
- 添加必要的测试
- 更新相关文档
- 确保构建成功

---

## 版本历史

- **v1.2** (2026-12-31)
  - 优化系统性能
  - 修复已知问题
  - 更新依赖版本

- **v1.1**
  - 新增温度查询功能
  - 改进 UI 设计
  - 优化应用管理功能

- **v1.0**
  - 首次发布
  - 基础功能实现

---

## 许可证

本项目采用 MIT 许可证 - 详见 [LICENSE](LICENSE) 文件

---

## 致谢

- [Shizuku](https://github.com/RikkaApps/Shizuku) - 提供无需 Root 的系统权限框架
- [Material Design 3](https://m3.material.io/) - 提供现代化设计指南
- [DialogX](https://github.com/kongzue/DialogX) - 提供优秀的对话框库

---

## 联系方式

- 作者：Viqitos
- 项目链接：[https://github.com/boxiaolanya2008/Huan-Tools](https://github.com/boxiaolanya2008/Huan-Tools)

---

## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=boxiaolanya2008/Huan-Tools&type=Date)](https://star-history.com/#boxiaolanya2008/Huan-Tools&Date)

---

<div align="center">

**如果这个项目对你有帮助，请给它一个 Star ⭐**

Made with ❤️ by Viqitos

</div>
