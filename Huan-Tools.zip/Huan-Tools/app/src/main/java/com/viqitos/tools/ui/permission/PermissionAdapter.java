package com.viqitos.tools.ui.permission;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.viqitos.tools.R;

import java.util.List;

public class PermissionAdapter extends RecyclerView.Adapter<PermissionAdapter.ViewHolder> {

    public interface OnPermissionClickListener {
        void onPermissionClick(PermissionInfo permissionInfo);
    }

    private final Context context;
    private final List<PermissionInfo> permissions;
    private final OnPermissionClickListener listener;

    public PermissionAdapter(Context context, List<PermissionInfo> permissions, OnPermissionClickListener listener) {
        this.context = context;
        this.permissions = permissions;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_permission, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PermissionInfo permission = permissions.get(position);

        holder.permissionName.setText(permission.displayName);
        holder.permissionDescription.setText(permission.description);
        if (permission.isGranted) {
            holder.permissionStatus.setText("已授予");
            holder.permissionStatus.setChipBackgroundColorResource(R.color.chip_user);
        } else {
            holder.permissionStatus.setText("未授予");
            holder.permissionStatus.setChipBackgroundColorResource(R.color.chip_system);
        }
        if (permission.isDangerous) {
            holder.permissionIcon.setImageResource(R.drawable.ic_settings);
        } else {
            holder.permissionIcon.setImageResource(R.drawable.ic_info);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onPermissionClick(permission);
            }
        });
    }

    @Override
    public int getItemCount() {
        return permissions.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView permissionIcon;
        TextView permissionName;
        TextView permissionDescription;
        Chip permissionStatus;

        ViewHolder(View itemView) {
            super(itemView);
            permissionIcon = itemView.findViewById(R.id.permission_icon);
            permissionName = itemView.findViewById(R.id.permission_name);
            permissionDescription = itemView.findViewById(R.id.permission_description);
            permissionStatus = itemView.findViewById(R.id.permission_status);
        }
    }
}
