package com.viqitos.tools.ui.appmanager;

import android.graphics.drawable.Drawable;

public class AppInfo {
    public String packageName;
    public String appName;
    public String versionName;
    public long versionCode;
    public boolean isSystemApp;
    public Drawable icon;
}
