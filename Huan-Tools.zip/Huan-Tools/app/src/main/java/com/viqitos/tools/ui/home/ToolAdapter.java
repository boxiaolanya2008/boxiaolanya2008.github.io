package com.viqitos.tools.ui.home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.viqitos.tools.R;
import java.util.List;

public class ToolAdapter
    extends RecyclerView.Adapter<ToolAdapter.ToolViewHolder> {

    public interface OnToolClickListener {
        void onToolClick(ToolItem toolItem);
    }

    private final Context context;
    private final List<ToolItem> tools;
    private final OnToolClickListener listener;

    public ToolAdapter(
        Context context,
        List<ToolItem> tools,
        OnToolClickListener listener
    ) {
        this.context = context;
        this.tools = tools;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ToolViewHolder onCreateViewHolder(
        @NonNull ViewGroup parent,
        int viewType
    ) {
        View view = LayoutInflater.from(context).inflate(
            R.layout.item_tool_card,
            parent,
            false
        );
        return new ToolViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ToolViewHolder holder, int position) {
        ToolItem tool = tools.get(position);
        holder.iconView.setImageResource(tool.iconResId);
        holder.titleView.setText(tool.title);
        holder.descriptionView.setText(tool.description);
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onToolClick(tool);
            }
        });
    }

    @Override
    public int getItemCount() {
        return tools.size();
    }

    static class ToolViewHolder extends RecyclerView.ViewHolder {

        ImageView iconView;
        TextView titleView;
        TextView descriptionView;

        ToolViewHolder(View itemView) {
            super(itemView);
            iconView = itemView.findViewById(R.id.tool_icon);
            titleView = itemView.findViewById(R.id.tool_title);
            descriptionView = itemView.findViewById(R.id.tool_description);
        }
    }
}
