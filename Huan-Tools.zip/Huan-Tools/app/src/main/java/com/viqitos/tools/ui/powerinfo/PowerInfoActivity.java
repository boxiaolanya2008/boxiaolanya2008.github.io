package com.viqitos.tools.ui.powerinfo;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.kongzue.dialogx.dialogs.BottomMenu;
import com.kongzue.dialogx.dialogs.InputDialog;
import com.kongzue.dialogx.dialogs.MessageDialog;
import com.kongzue.dialogx.dialogs.PopTip;
import com.kongzue.dialogx.dialogs.WaitDialog;
import com.viqitos.tools.R;
import com.viqitos.tools.utils.ShizukuHelper;
import com.viqitos.tools.utils.XmlConfigManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.List;

import rikka.shizuku.Shizuku;

public class PowerInfoActivity extends AppCompatActivity {

    private TextView txtBatteryLevel;
    private TextView txtBatteryStatus;
    private TextView txtBatteryHealth;
    private TextView txtBatteryVoltage;
    private TextView txtBatteryTemp;
    private RecyclerView recyclerConfig;

    private XmlConfigManager xmlConfigManager;
    private ConfigAdapter configAdapter;
    private BroadcastReceiver batteryReceiver;

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    PopTip.show("存储权限已授予");
                } else {
                    PopTip.show("存储权限被拒绝，无法导入/导出配置");
                }
            });

    private final ActivityResultLauncher<Intent> manageStorageLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    if (Environment.isExternalStorageManager()) {
                        PopTip.show("已获得管理所有文件权限");
                    } else {
                        MessageDialog.show("权限不足",
                                "未授予管理所有文件权限。\n\n导入/导出功能可能无法正常使用。\n\n如需使用，请在系统设置中手动授予权限。",
                                "确定");
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_power_info);

        xmlConfigManager = new XmlConfigManager(this);

        setupViews();
        loadConfigData();
        registerBatteryReceiver();
    }

    private void setupViews() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("电源信息");
        }
        txtBatteryLevel = findViewById(R.id.txt_battery_level);
        txtBatteryStatus = findViewById(R.id.txt_battery_status);
        txtBatteryHealth = findViewById(R.id.txt_battery_health);
        txtBatteryVoltage = findViewById(R.id.txt_battery_voltage);
        txtBatteryTemp = findViewById(R.id.txt_battery_temp);
        recyclerConfig = findViewById(R.id.recycler_config);
        recyclerConfig.setLayoutManager(new LinearLayoutManager(this));
        MaterialButton btnRefresh = findViewById(R.id.btn_refresh);
        MaterialButton btnEnhanceParams = findViewById(R.id.btn_enhance_params);

        btnRefresh.setOnClickListener(v -> refreshBatteryInfo());
        btnEnhanceParams.setOnClickListener(v -> executeEnhanceParams());
        checkStoragePermission();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_power_info, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        
        if (id == android.R.id.home) {
            finish();
            return true;
        } else if (id == R.id.action_import_export) {
            showImportExportMenu();
            return true;
        }
        
        return super.onOptionsItemSelected(item);
    }

    private void checkStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                MessageDialog.show("需要授予权限",
                        "请授予“管理所有文件”权限，以便将配置导出到\n/sdcard/\n\n点击“授予权限”跳转到设置界面。",
                        "授予权限", "稍后"
                ).setOkButtonClickListener((dialog, v) -> {
                    try {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        manageStorageLauncher.launch(intent);
                    } catch (Exception e) {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                        manageStorageLauncher.launch(intent);
                    }
                    return false;
                });
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
        }
    }

    private void showImportExportMenu() {
        BottomMenu.show(new String[]{
                "导出配置",
                "导入配置",
                "查看导出目录"
        }).setOnMenuItemClickListener((dialog, text, index) -> {
            switch (index) {
                case 0:
                    exportConfig();
                    break;
                case 1:
                    importConfig();
                    break;
                case 2:
                    showExportDir();
                    break;
            }
            return false;
        });
    }

    private void exportConfig() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                MessageDialog.show("权限不足",
                        "需要“管理所有文件”权限才能导出配置。\n\n请先授予权限。",
                        "去授权", "取消"
                ).setOkButtonClickListener((dialog, v) -> {
                    checkStoragePermission();
                    return false;
                });
                return;
            }
        }

        MessageDialog.show("导出配置",
                "将当前的电源配置（包含您的修改）导出为XML文件。\n\n" +
                "⚠️ 文件名固定为：fuelsummary_uc.xml\n" +
                "⚠️ 导出路径固定为：/sdcard/\n" +
                "⚠️ 这两个参数不可修改，不提供自定义选项",
                "导出", "取消"
        ).setOkButtonClickListener((dialogInterface, v) -> {
            WaitDialog.show("正在导出配置...");

            new Thread(() -> {
                try {
                    Thread.sleep(500);
                    String exportPath = xmlConfigManager.exportConfigToFile();

                    runOnUiThread(() -> {
                        WaitDialog.dismiss();
                        if (exportPath != null) {
                            MessageDialog.show("导出成功",
                                    "配置已成功导出至：\n\n" + exportPath +
                                    "\n\n⚠️ 文件固定为 fuelsummary_uc.xml，保存在 /sdcard/ 根目录。" +
                                    "\n\n您可以使用任意文本编辑器手动编辑，" +
                                    "然后通过导入功能加载修改后的配置。",
                                    "确定");
                        } else {
                            MessageDialog.show("导出失败",
                                    "无法导出配置文件。\n\n请检查：\n1. 是否已授予存储权限\n2. 存储空间是否充足",
                                    "确定");
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        WaitDialog.dismiss();
                        MessageDialog.show("错误", "导出过程中发生错误：" + e.getMessage(), "确定");
                    });
                }
            }).start();

            return false;
        });
    }

    private void importConfig() {
        String defaultPath = "/sdcard/fuelsummary_uc.xml";

        InputDialog.show("导入配置",
                "请输入配置文件的完整路径：\n\n支持 fuelsummary_uc.xml 原始格式\n默认路径：" + defaultPath,
                "确定", "取消"
        ).setInputText(defaultPath)
        .setInputHintText("例如：/sdcard/fuelsummary_uc.xml")
        .setOkButtonClickListener((dialogInterface, v, inputStr) -> {
            if (inputStr == null || inputStr.trim().isEmpty()) {
                PopTip.show("请输入文件路径");
                return false;
            }

            String filePath = inputStr.trim();
            File file = new File(filePath);

            if (!file.exists()) {
                MessageDialog.show("文件不存在",
                        "指定的文件不存在：\n" + filePath,
                        "确定");
                return false;
            }

            WaitDialog.show("正在导入配置...");

            new Thread(() -> {
                try {
                    Thread.sleep(500);
                    boolean success = xmlConfigManager.importConfigFromFile(filePath);

                    runOnUiThread(() -> {
                        WaitDialog.dismiss();
                        if (success) {
                            loadConfigData();
                            MessageDialog.show("导入成功",
                                    "配置已成功从文件加载：\n\n" + filePath +
                                    "\n\n新配置已应用到界面上。\n" +
                                    "格式：fuelsummary_uc.xml 原始结构。",
                                    "确定");
                        } else {
                            MessageDialog.show("导入失败",
                                    "无法导入配置文件。\n\n请检查：\n" +
                                    "1. 文件是否为 fuelsummary_uc.xml 格式\n" +
                                    "2. XML 语法是否正确\n" +
                                    "3. 文件是否包含必要的配置节点\n" +
                                    "4. 文件是否可读",
                                    "确定");
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        WaitDialog.dismiss();
                        MessageDialog.show("错误", "导入过程中发生错误：" + e.getMessage(), "确定");
                    });
                }
            }).start();

            return false;
        });
    }

    private void showExportDir() {
        String dirPath = xmlConfigManager.getExportDirPath();
        File dir = new File(dirPath);

        StringBuilder info = new StringBuilder();
        info.append("⚠️ 导出路径固定为：\n").append(dirPath).append("\n\n");
        info.append("⚠️ 导出文件名固定为：fuelsummary_uc.xml\n\n");
        info.append("这两个参数是硬性规定，不可修改，不提供自定义选项。\n\n");

        File exportFile = new File(dirPath, "fuelsummary_uc.xml");
        if (exportFile.exists() && exportFile.isFile()) {
            info.append("当前已存在配置文件：\n\n");
            info.append("• fuelsummary_uc.xml\n");
            info.append("  大小: ").append(exportFile.length() / 1024).append(" KB\n");
            info.append("  路径: ").append(exportFile.getAbsolutePath()).append("\n\n");
            info.append("⚠️ 再次导出将覆盖此文件。");
        } else {
            info.append("当前还没有导出的配置文件。\n\n");
            info.append("首次导出后，文件将保存为：\n");
            info.append(dirPath + "fuelsummary_uc.xml");
        }

        MessageDialog.show("导出配置信息", info.toString(), "确定");
    }

    private void showEditDialog(XmlConfigManager.XmlConfigItem item, XmlConfigManager.XmlConfigGroup group) {
        String title = "编辑参数: " + item.name;
        String message = item.description + "\n\n类型: " + item.type + "\n当前值: " + item.value;
        String hint = getInputHint(item.type);

        InputDialog.show(title, message, "保存", "取消")
            .setInputText(item.value)
            .setInputHintText(hint)
            .setOkButtonClickListener((dialogInterface, v, inputStr) -> {
                if (inputStr == null || inputStr.trim().isEmpty()) {
                    PopTip.show("请输入值");
                    return false;
                }

                String newValue = inputStr.trim();
                if (!validateInput(newValue, item.type)) {
                    PopTip.show("输入格式不正确");
                    return false;
                }
                item.value = newValue;
                configAdapter.notifyDataSetChanged();

                PopTip.show("修改成功");

                return false;
            });
    }

    private String getInputHint(String type) {
        switch (type) {
            case "integer":
                return "请输入整数，例如：100";
            case "integer-array":
                return "请输入空格分隔的整数，例如：46 50 54";
            case "hex-array":
                return "请输入空格分隔的十六进制数，例如：A9 1F 22 E3";
            default:
                return "请输入新值";
        }
    }

    private boolean validateInput(String value, String type) {
        try {
            switch (type) {
                case "integer":
                    Integer.parseInt(value);
                    return true;

                case "integer-array":
                    String[] parts = value.trim().split("\\s+");
                    for (String part : parts) {
                        String cleanPart = part.replace("(", "").replace(")", "");
                        Integer.parseInt(cleanPart);
                    }
                    return true;

                case "hex-array":
                    String[] hexParts = value.trim().split("\\s+");
                    for (String hexPart : hexParts) {
                        Integer.parseInt(hexPart, 16);
                    }
                    return true;

                default:
                    return true;
            }
        } catch (Exception e) {
            return false;
        }
    }

    private void loadConfigData() {
        List<XmlConfigManager.XmlConfigGroup> groups = xmlConfigManager.getCurrentConfig();
        configAdapter = new ConfigAdapter(groups);
        recyclerConfig.setAdapter(configAdapter);
    }

    private void registerBatteryReceiver() {
        batteryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                updateBatteryInfo(intent);
            }
        };

        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(batteryReceiver, filter);
    }

    private void refreshBatteryInfo() {
        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, ifilter);
        if (batteryStatus != null) {
            updateBatteryInfo(batteryStatus);
            PopTip.show("电池信息已刷新");
        }
    }

    private void updateBatteryInfo(Intent intent) {
        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        int batteryPct = (int) ((level / (float) scale) * 100);
        txtBatteryLevel.setText(batteryPct + "%");
        int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        txtBatteryStatus.setText(getBatteryStatusText(status));
        int health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1);
        txtBatteryHealth.setText(getBatteryHealthText(health));
        int voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
        if (voltage > 0) {
            DecimalFormat df = new DecimalFormat("#.##");
            txtBatteryVoltage.setText(df.format(voltage / 1000.0) + " V");
        } else {
            txtBatteryVoltage.setText("未知");
        }
        int temperature = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        if (temperature > 0) {
            DecimalFormat df = new DecimalFormat("#.#");
            txtBatteryTemp.setText(df.format(temperature / 10.0) + " °C");
        } else {
            txtBatteryTemp.setText("未知");
        }
    }

    private String getBatteryStatusText(int status) {
        switch (status) {
            case BatteryManager.BATTERY_STATUS_CHARGING:
                return "充电中";
            case BatteryManager.BATTERY_STATUS_DISCHARGING:
                return "放电中";
            case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                return "未充电";
            case BatteryManager.BATTERY_STATUS_FULL:
                return "已充满";
            default:
                return "未知";
        }
    }

    private String getBatteryHealthText(int health) {
        switch (health) {
            case BatteryManager.BATTERY_HEALTH_GOOD:
                return "良好";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                return "过热";
            case BatteryManager.BATTERY_HEALTH_DEAD:
                return "损坏";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                return "过压";
            case BatteryManager.BATTERY_HEALTH_COLD:
                return "过冷";
            default:
                return "未知";
        }
    }

    private void executeEnhanceParams() {
        MessageDialog.show("执行增强参数",
                "此功能将执行电池增强参数命令。\n\n需要Shizuku权限\n确定要执行吗？",
                "执行", "取消"
        ).setOkButtonClickListener((dialog, v) -> {
            if (!checkShizukuPermission()) {
                MessageDialog.show("权限不足",
                        "需要Shizuku权限才能执行增强参数命令\n\n请确保：\n1. 已安装并启动Shizuku\n2. 已授予本应用Shizuku权限",
                        "确定");
                return false;
            }

            WaitDialog.show("正在执行增强参数命令...");

            new Thread(() -> {
                String result = executeEnhanceCommandInternal();
                runOnUiThread(() -> {
                    WaitDialog.dismiss();
                    MessageDialog.show("执行结果", result, "确定");
                });
            }).start();

            return false;
        });
    }

    private boolean checkShizukuPermission() {
        try {
            return Shizuku.pingBinder() &&
                   Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            return false;
        }
    }

    private String executeEnhanceCommandInternal() {
        String[] commands = new String[]{
                "am broadcast -a android.provider.Telephony.VIVO_SECRET_CODE -d android_vivo_sec_code://7083 >/dev/null",
                "am broadcast -a android.provider.Telephony.VIVO_SECRET_CODE -d android_vivo_sec_code://113 >/dev/null",
                "am broadcast -a android.provider.Telephony.VIVO_SECRET_CODE -d android_vivo_sec_code://7076 >/dev/null",
                "am broadcast -a android.provider.Telephony.VIVO_SECRET_CODE -d android_vivo_sec_code://5131 >/dev/null",
                "am broadcast -a android.provider.Telephony.VIVO_SECRET_CODE -d android_vivo_sec_code://5130 >/dev/null",
                "am broadcast -a com.vivo.fuelsummary.SDA_AGING_CLEAR >/dev/null",
                "am startservice -n com.vivo.fuelsummary/.FuelSummaryService >/dev/null",
                "am broadcast -a com.vivo.fuelsummary.FuelSummaryReceiver >/dev/null"
        };

        StringBuilder output = new StringBuilder();
        int successCount = 0;

        for (String command : commands) {
            try {
                Process process = Shizuku.newProcess(new String[]{"sh", "-c", command}, null, null);
                int exitCode = process.waitFor();

                if (exitCode == 0) {
                    successCount++;
                }
            } catch (Exception e) {
                output.append("✗ 执行异常: ").append(e.getMessage()).append("\n");
            }
        }

        return "✅ 增强参数执行完成\n成功: " + successCount + "/" + commands.length + " 条命令";
    }

        private class ConfigAdapter extends RecyclerView.Adapter<ConfigAdapter.ViewHolder> {

        private List<XmlConfigManager.XmlConfigGroup> groups;

        public ConfigAdapter(List<XmlConfigManager.XmlConfigGroup> groups) {
            this.groups = groups;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_config_group, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            XmlConfigManager.XmlConfigGroup group = groups.get(position);
            holder.bind(group);
        }

        @Override
        public int getItemCount() {
            return groups.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView txtGroupName;
            LinearLayout layoutItems;

            public ViewHolder(View itemView) {
                super(itemView);
                txtGroupName = itemView.findViewById(R.id.txt_group_name);
                layoutItems = itemView.findViewById(R.id.layout_items);
            }

            public void bind(XmlConfigManager.XmlConfigGroup group) {
                txtGroupName.setText(group.name);
                layoutItems.removeAllViews();

                for (XmlConfigManager.XmlConfigItem item : group.items) {
                    View paramView = LayoutInflater.from(itemView.getContext())
                            .inflate(R.layout.item_config_param, layoutItems, false);

                    TextView txtName = paramView.findViewById(R.id.txt_param_name);
                    TextView txtValue = paramView.findViewById(R.id.txt_param_value);
                    TextView txtDesc = paramView.findViewById(R.id.txt_param_desc);

                    txtName.setText(item.name);
                    txtValue.setText(item.value);
                    txtDesc.setText(item.description);

                                        paramView.setOnClickListener(v -> showEditDialog(item, group));
                    paramView.setClickable(true);
                    paramView.setFocusable(true);

                    layoutItems.addView(paramView);
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (batteryReceiver != null) {
            unregisterReceiver(batteryReceiver);
        }
    }
}
