package com.viqitos.tools.ui.appmanager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.chip.Chip;
import com.viqitos.tools.R;
import java.util.List;

public class AppManagerAdapter
    extends RecyclerView.Adapter<AppManagerAdapter.ViewHolder> {

    public interface OnAppActionListener {
        void onAction(AppInfo appInfo, String action);
    }

    private final Context context;
    private final List<AppInfo> apps;
    private final OnAppActionListener listener;

    public AppManagerAdapter(
        Context context,
        List<AppInfo> apps,
        OnAppActionListener listener
    ) {
        this.context = context;
        this.apps = apps;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(
        @NonNull ViewGroup parent,
        int viewType
    ) {
        View view = LayoutInflater.from(context).inflate(
            R.layout.item_app,
            parent,
            false
        );
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AppInfo app = apps.get(position);

        holder.iconView.setImageDrawable(app.icon);
        holder.nameView.setText(app.appName);
        holder.packageView.setText(app.packageName);
        holder.versionView.setText("v" + app.versionName);

        if (app.isSystemApp) {
            holder.typeChip.setText("系统");
            holder.typeChip.setChipBackgroundColorResource(R.color.chip_system);
        } else {
            holder.typeChip.setText("用户");
            holder.typeChip.setChipBackgroundColorResource(R.color.chip_user);
        }

        holder.cardView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onAction(app, "info");
            }
        });

        holder.cardView.setOnLongClickListener(v -> {
            showActionMenu(app);
            return true;
        });
    }

    private void showActionMenu(AppInfo app) {
        String[] actions = {
            "查看详情",
            "强制停止",
            "清除数据",
            "编译应用",
            "重置编译",
            "卸载应用",
            "后台数据",
            "杀死进程",
            "释放内存",
            "取消后台Job",
        };
        com.kongzue.dialogx.dialogs.BottomMenu.show(
            actions
        ).setOnMenuItemClickListener((dialog, text, index) -> {
            switch (index) {
                case 0:
                    listener.onAction(app, "info");
                    break;
                case 1:
                    listener.onAction(app, "force_stop");
                    break;
                case 2:
                    listener.onAction(app, "clear_data");
                    break;
                case 3:
                    listener.onAction(app, "compile");
                    break;
                case 4:
                    listener.onAction(app, "reset_compile");
                    break;
                case 5:
                    listener.onAction(app, "uninstall");
                    break;
                case 6:
                    listener.onAction(app, "background_data");
                    break;
                case 7:
                    listener.onAction(app, "kill_process");
                    break;
                case 8:
                    listener.onAction(app, "trim_memory");
                    break;
                case 9:
                    listener.onAction(app, "cancel_jobs");
                    break;
            }
            return false;
        });
    }

    @Override
    public int getItemCount() {
        return apps.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        MaterialCardView cardView;
        ImageView iconView;
        TextView nameView;
        TextView packageView;
        TextView versionView;
        Chip typeChip;

        ViewHolder(View itemView) {
            super(itemView);
            cardView = (MaterialCardView) itemView;
            iconView = itemView.findViewById(R.id.app_icon);
            nameView = itemView.findViewById(R.id.app_name);
            packageView = itemView.findViewById(R.id.app_package);
            versionView = itemView.findViewById(R.id.app_version);
            typeChip = itemView.findViewById(R.id.app_type_chip);
        }
    }
}
