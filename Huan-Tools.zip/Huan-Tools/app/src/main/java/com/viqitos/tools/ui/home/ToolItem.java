package com.viqitos.tools.ui.home;

public class ToolItem {

    public final int iconResId;
    public final String title;
    public final String description;
    public final String action;

    public ToolItem(
        int iconResId,
        String title,
        String description,
        String action
    ) {
        this.iconResId = iconResId;
        this.title = title;
        this.description = description;
        this.action = action;
    }
}
