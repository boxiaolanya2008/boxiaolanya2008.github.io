package com.viqitos.tools.utils;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CrashLogManager {
    private static final String TAG = "CrashLogManager";
    private static final String LOG_DIR = "ViqitosTools/CrashLogs";
    private static CrashLogManager instance;
    private Context context;

    private CrashLogManager(Context context) {
        this.context = context.getApplicationContext();
    }

    public static synchronized CrashLogManager getInstance(Context context) {
        if (instance == null) {
            instance = new CrashLogManager(context);
        }
        return instance;
    }

    public void saveCrashLog(Thread thread, Throwable throwable) {
        try {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            throwable.printStackTrace(pw);
            String crashLog = sw.toString();
            pw.close();

            StringBuilder logContent = new StringBuilder();
            logContent.append("=== Crash Log ===\n");
            logContent.append("Time: ").append(getCurrentTime()).append("\n");
            logContent.append("Thread: ").append(thread.getName()).append(" (ID: ").append(thread.getId()).append(")\n");
            logContent.append("Exception: ").append(throwable.getClass().getName()).append("\n");
            logContent.append("Message: ").append(throwable.getMessage()).append("\n");
            logContent.append("Stack Trace:\n").append(crashLog).append("\n");
            logContent.append("=== End of Log ===\n\n");

            String fileName = "crash_" + getCurrentTimeForFileName() + ".log";
            saveToFile(logContent.toString(), fileName);

            Log.d(TAG, "Crash log saved to: " + fileName);
        } catch (Exception e) {
            Log.e(TAG, "Failed to save crash log", e);
        }
    }

    private void saveToFile(String content, String fileName) {
        FileOutputStream fos = null;
        try {
            File logDir = new File(context.getExternalFilesDir(null), LOG_DIR);
            if (!logDir.exists()) {
                logDir.mkdirs();
            }

            File logFile = new File(logDir, fileName);
            fos = new FileOutputStream(logFile);
            fos.write(content.getBytes());
            fos.flush();
        } catch (Exception e) {
            Log.e(TAG, "Failed to write log to file", e);
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (Exception e) {
                    Log.e(TAG, "Failed to close file output stream", e);
                }
            }
        }
    }

    private String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }

    private String getCurrentTimeForFileName() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
        return sdf.format(new Date());
    }

    public File getLogDirectory() {
        return new File(context.getExternalFilesDir(null), LOG_DIR);
    }

    public String getAllCrashLogs() {
        StringBuilder allLogs = new StringBuilder();
        File logDir = getLogDirectory();

        if (!logDir.exists() || !logDir.isDirectory()) {
            return "";
        }

        File[] logFiles = logDir.listFiles();
        if (logFiles == null || logFiles.length == 0) {
            return "";
        }

        java.util.Arrays.sort(logFiles, (f1, f2) -> f2.getName().compareTo(f1.getName()));

        for (File logFile : logFiles) {
            if (logFile.isFile() && logFile.getName().endsWith(".log")) {
                try {
                    java.io.BufferedReader reader = new java.io.BufferedReader(
                        new java.io.FileReader(logFile));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        allLogs.append(line).append("\n");
                    }
                    reader.close();
                    allLogs.append("\n");
                } catch (Exception e) {
                    Log.e(TAG, "Failed to read log file: " + logFile.getName(), e);
                }
            }
        }

        return allLogs.toString();
    }
}
