package com.viqitos.tools.ui.appmanager;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.MaterialToolbar;
import com.kongzue.dialogx.dialogs.MessageDialog;
import com.kongzue.dialogx.dialogs.PopTip;
import com.kongzue.dialogx.dialogs.WaitDialog;
import com.viqitos.tools.R;
import com.viqitos.tools.utils.ShizukuHelper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AppManagerActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AppManagerAdapter adapter;
    private EditText searchEdit;
    private List<AppInfo> allApps = new ArrayList<>();
    private List<AppInfo> filteredApps = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_manager);

        if (!ShizukuHelper.isShizukuAvailable()) {
            PopTip.show("需要Shizuku权限才能使用应用管理功能");
            finish();
            return;
        }

        setupViews();
        loadApps();
    }

    private void setupViews() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("应用管理");
        }

        searchEdit = findViewById(R.id.search_edit);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new AppManagerAdapter(this, filteredApps, this::onAppAction);
        recyclerView.setAdapter(adapter);

        searchEdit.addTextChangedListener(
            new TextWatcher() {
                @Override
                public void beforeTextChanged(
                    CharSequence s,
                    int start,
                    int count,
                    int after
                ) {}

                @Override
                public void onTextChanged(
                    CharSequence s,
                    int start,
                    int before,
                    int count
                ) {
                    filterApps(s.toString());
                }

                @Override
                public void afterTextChanged(Editable s) {}
            }
        );
    }

    private void loadApps() {
        WaitDialog.show("加载中...");
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            List<PackageInfo> packages = pm.getInstalledPackages(
                PackageManager.GET_META_DATA
            );

            allApps.clear();
            for (PackageInfo packageInfo : packages) {
                ApplicationInfo appInfo = packageInfo.applicationInfo;

                AppInfo info = new AppInfo();
                info.packageName = packageInfo.packageName;
                info.appName = appInfo.loadLabel(pm).toString();
                info.versionName = packageInfo.versionName;
                info.versionCode = packageInfo.versionCode;
                info.isSystemApp =
                    (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                info.icon = appInfo.loadIcon(pm);

                allApps.add(info);
            }

            Collections.sort(allApps, (a, b) ->
                a.appName.compareToIgnoreCase(b.appName)
            );

            runOnUiThread(() -> {
                filteredApps.clear();
                filteredApps.addAll(allApps);
                adapter.notifyDataSetChanged();
                WaitDialog.dismiss();
            });
        })
            .start();
    }

    private void filterApps(String query) {
        filteredApps.clear();
        if (query.isEmpty()) {
            filteredApps.addAll(allApps);
        } else {
            String lowerQuery = query.toLowerCase();
            for (AppInfo app : allApps) {
                if (
                    app.appName.toLowerCase().contains(lowerQuery) ||
                    app.packageName.toLowerCase().contains(lowerQuery)
                ) {
                    filteredApps.add(app);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void onAppAction(AppInfo appInfo, String action) {
        switch (action) {
            case "uninstall":
                uninstallApp(appInfo);
                break;
            case "clear_data":
                clearAppData(appInfo);
                break;
            case "force_stop":
                forceStopApp(appInfo);
                break;
            case "compile":
                compileApp(appInfo);
                break;
            case "reset_compile":
                resetCompileApp(appInfo);
                break;
            case "info":
                showAppInfo(appInfo);
                break;
            case "background_data":
                backgroundDataAction(appInfo);
                break;
            case "kill_process":
                killProcess(appInfo);
                break;
            case "trim_memory":
                trimMemory(appInfo);
                break;
            case "cancel_jobs":
                cancelJobs(appInfo);
                break;
        }
    }

    private void uninstallApp(AppInfo appInfo) {
        String[] options = { "完全卸载", "保留数据卸载" };
        com.kongzue.dialogx.dialogs.BottomMenu.show(options)
            .setTitle("卸载 " + appInfo.appName)
            .setOnMenuItemClickListener((dialog, text, index) -> {
                boolean keepData = (index == 1);
                String message = appInfo.isSystemApp
                    ? "这是系统应用,将仅为当前用户卸载。\n" +
                      (keepData ? "应用数据将被保留。" : "应用数据将被清除。")
                    : "确定要卸载此应用吗？\n" +
                      (keepData ? "应用数据将被保留。" : "应用数据将被清除。");

                MessageDialog.show(
                    "卸载应用",
                    message,
                    "确定",
                    "取消"
                ).setOkButtonClickListener((d, v) -> {
                    WaitDialog.show("正在卸载...");

                    String command;
                    if (appInfo.isSystemApp) {
                        command =
                            "pm uninstall --user 0 " +
                            (keepData ? "-k " : "") +
                            appInfo.packageName;
                    } else {
                        command =
                            "pm uninstall " +
                            (keepData ? "-k " : "") +
                            appInfo.packageName;
                    }

                    ShizukuHelper.executeShellCommand(command, result -> {
                        runOnUiThread(() -> {
                            WaitDialog.dismiss();
                            if (result.contains("Success")) {
                                PopTip.show("卸载成功");
                                loadApps();
                            } else {
                                PopTip.show("卸载失败: " + result);
                            }
                        });
                    });
                    return false;
                });
                return false;
            });
    }

    private void backgroundDataAction(AppInfo appInfo) {
        String[] options = { "禁止后台数据访问", "恢复后台数据访问" };
        com.kongzue.dialogx.dialogs.BottomMenu.show(options)
            .setTitle("后台数据控制")
            .setOnMenuItemClickListener((dialog, text, index) -> {
                String command =
                    "cmd netpolicy set restrict-background " +
                    appInfo.packageName +
                    " " +
                    (index == 0 ? "true" : "false");
                String actionDesc = index == 0 ? "禁止" : "恢复";
                MessageDialog.show(
                    "后台数据",
                    "确定要" +
                        actionDesc +
                        " " +
                        appInfo.appName +
                        " 的后台数据访问吗？",
                    "确定",
                    "取消"
                ).setOkButtonClickListener((d, v) -> {
                    WaitDialog.show("处理中...");
                    ShizukuHelper.executeShellCommand(command, result -> {
                        runOnUiThread(() -> {
                            WaitDialog.dismiss();
                            if (
                                result.contains("Success") ||
                                result.trim().isEmpty()
                            ) {
                                PopTip.show(actionDesc + "成功");
                            } else {
                                PopTip.show(actionDesc + "失败: " + result);
                            }
                        });
                    });
                    return false;
                });
                return false;
            });
    }

    private void killProcess(AppInfo appInfo) {
        getAppPid(appInfo, pid -> {
            if (pid == -1) {
                PopTip.show("无法获取进程ID");
                return;
            }
            MessageDialog.show(
                "杀死进程",
                "确定要杀死 " +
                    appInfo.appName +
                    " 的活动进程吗？\nPID: " +
                    pid,
                "确定",
                "取消"
            ).setOkButtonClickListener((d, v) -> {
                WaitDialog.show("正在杀死...");
                String command = "dumpsys activity kill " + pid;
                ShizukuHelper.executeShellCommand(command, result -> {
                    runOnUiThread(() -> {
                        WaitDialog.dismiss();
                        PopTip.show("杀死进程完成");
                    });
                });
                return false;
            });
        });
    }

    private void trimMemory(AppInfo appInfo) {
        getAppPid(appInfo, pid -> {
            if (pid == -1) {
                PopTip.show("无法获取进程ID");
                return;
            }
            MessageDialog.show(
                "释放内存",
                "确定要释放 " +
                    appInfo.appName +
                    " 的运行内存吗？\nPID: " +
                    pid,
                "确定",
                "取消"
            ).setOkButtonClickListener((d, v) -> {
                WaitDialog.show("正在释放...");
                String command = "am send-trim-memory " + pid + " RUNNING_LOW";
                ShizukuHelper.executeShellCommand(command, result -> {
                    runOnUiThread(() -> {
                        WaitDialog.dismiss();
                        if (
                            result.trim().isEmpty() ||
                            result.contains("finished")
                        ) {
                            PopTip.show("释放内存完成");
                        } else {
                            PopTip.show("释放失败: " + result);
                        }
                    });
                });
                return false;
            });
        });
    }

    private void cancelJobs(AppInfo appInfo) {
        MessageDialog.show(
            "取消后台Job",
            "确定要取消 " + appInfo.appName + " 的所有后台Job吗？",
            "确定",
            "取消"
        ).setOkButtonClickListener((d, v) -> {
            WaitDialog.show("正在取消...");
            String command = "cmd jobscheduler cancel " + appInfo.packageName;
            ShizukuHelper.executeShellCommand(command, result -> {
                runOnUiThread(() -> {
                    WaitDialog.dismiss();
                    PopTip.show("取消后台Job完成");
                });
            });
            return false;
        });
    }

    private void getAppPid(AppInfo appInfo, OnPidRetrievedListener listener) {
        String command = "ps -A | grep '" + appInfo.packageName + "'";
        ShizukuHelper.executeShellCommand(command, result -> {
            int pid = -1;
            String[] lines = result.split("\n");
            for (String line : lines) {
                line = line.trim();
                if (line.contains(appInfo.packageName)) {
                    String[] parts = line.split("\\s+");
                    if (parts.length > 1) {
                        try {
                            pid = Integer.parseInt(parts[0]);
                            break;
                        } catch (NumberFormatException e) {
                        }
                    }
                }
            }
            listener.onPidRetrieved(pid);
        });
    }

    private interface OnPidRetrievedListener {
        void onPidRetrieved(int pid);
    }

    private void clearAppData(AppInfo appInfo) {
        MessageDialog.show(
            "清除数据",
            "确定要清除 " + appInfo.appName + " 的数据吗？",
            "确定",
            "取消"
        ).setOkButtonClickListener((dialog, v) -> {
            WaitDialog.show("正在清除...");
            ShizukuHelper.executeShellCommand(
                "pm clear " + appInfo.packageName,
                result -> {
                    runOnUiThread(() -> {
                        WaitDialog.dismiss();
                        if (result.contains("Success")) {
                            PopTip.show("清除成功");
                        } else {
                            PopTip.show("清除失败: " + result);
                        }
                    });
                }
            );
            return false;
        });
    }

    private void forceStopApp(AppInfo appInfo) {
        WaitDialog.show("正在停止...");
        ShizukuHelper.executeShellCommand(
            "am force-stop " + appInfo.packageName,
            result -> {
                runOnUiThread(() -> {
                    WaitDialog.dismiss();
                    PopTip.show("已停止 " + appInfo.appName);
                });
            }
        );
    }

    private void compileApp(AppInfo appInfo) {
        String[] modes = {
            "speed (推荐)",
            "speed-profile (均衡)",
            "everything (完全编译)",
            "verify (仅验证)",
            "quicken (快速)",
            "space (节省空间)",
        };
        com.kongzue.dialogx.dialogs.BottomMenu.show(modes)
            .setTitle("选择编译模式")
            .setOnMenuItemClickListener((dialog, text, index) -> {
                String[] modeNames = {
                    "speed",
                    "speed-profile",
                    "everything",
                    "verify",
                    "quicken",
                    "space",
                };
                String selectedMode = modeNames[index];

                MessageDialog.show(
                    "编译应用",
                    "确定使用 " +
                        text +
                        " 模式编译 " +
                        appInfo.appName +
                        " 吗？\n\n这将优化应用性能，但可能需要一些时间。",
                    "确定",
                    "取消"
                ).setOkButtonClickListener((d, v) -> {
                    WaitDialog.show("正在编译...");
                    ShizukuHelper.executeShellCommand(
                        "cmd package compile -m " +
                            selectedMode +
                            " -f " +
                            appInfo.packageName,
                        result -> {
                            runOnUiThread(() -> {
                                WaitDialog.dismiss();
                                if (
                                    result.contains("Success") ||
                                    result.contains("success")
                                ) {
                                    PopTip.show("编译成功");
                                } else if (
                                    result.contains("Failure") ||
                                    result.contains("failure")
                                ) {
                                    PopTip.show("编译失败: " + result);
                                } else {
                                    PopTip.show("编译完成");
                                }
                            });
                        }
                    );
                    return false;
                });
                return false;
            });
    }

    private void resetCompileApp(AppInfo appInfo) {
        MessageDialog.show(
            "重置编译",
            "确定要重置 " +
                appInfo.appName +
                " 的编译状态吗？\n\n这将清除已编译的代码。",
            "确定",
            "取消"
        ).setOkButtonClickListener((dialog, v) -> {
            WaitDialog.show("正在重置...");
            ShizukuHelper.executeShellCommand(
                "cmd package compile --reset " + appInfo.packageName,
                result -> {
                    runOnUiThread(() -> {
                        WaitDialog.dismiss();
                        if (
                            result.contains("Success") ||
                            result.contains("success")
                        ) {
                            PopTip.show("重置成功");
                        } else if (
                            result.contains("Failure") ||
                            result.contains("failure")
                        ) {
                            PopTip.show("重置失败: " + result);
                        } else {
                            PopTip.show("重置完成");
                        }
                    });
                }
            );
            return false;
        });
    }

    private void showAppInfo(AppInfo appInfo) {
        String info =
            "应用名称: " +
            appInfo.appName +
            "\n" +
            "包名: " +
            appInfo.packageName +
            "\n" +
            "版本: " +
            appInfo.versionName +
            " (" +
            appInfo.versionCode +
            ")\n" +
            "类型: " +
            (appInfo.isSystemApp ? "系统应用" : "用户应用");

        MessageDialog.show("应用信息", info, "确定");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
