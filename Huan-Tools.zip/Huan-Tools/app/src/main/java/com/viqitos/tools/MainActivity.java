package com.viqitos.tools;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.kongzue.dialogx.dialogs.MessageDialog;
import com.kongzue.dialogx.dialogs.PopTip;
import com.viqitos.tools.databinding.ActivityMainBinding;
import com.viqitos.tools.utils.CardVerificationManager;
import com.viqitos.tools.utils.CrashHandler;
import com.viqitos.tools.utils.PreferencesManager;
import com.viqitos.tools.utils.ShizukuHelper;
import com.viqitos.tools.utils.UpdateManager;

import java.io.File;

import rikka.shizuku.Shizuku;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    private ActivityMainBinding binding;
    private PreferencesManager preferencesManager;
    private UpdateManager updateManager;
    private CardVerificationManager cardVerificationManager;

    private final ActivityResultLauncher<String> requestNotificationPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    Log.d(TAG, "Notification permission granted");
                    PopTip.show("通知权限已授予");
                    preferencesManager.setPushNotificationsEnabled(true);
                } else {
                    Log.d(TAG, "Notification permission denied");
                    PopTip.show("通知权限被拒绝");
                    preferencesManager.setPushNotificationsEnabled(false);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        CrashHandler.getInstance().init(this);

        preferencesManager = PreferencesManager.getInstance(this);

        updateManager = new UpdateManager(this);
        updateManager.setUpdateCallback(new UpdateManager.UpdateCallback() {
            @Override
            public void onUpdateAvailable(UpdateManager.UpdateInfo updateInfo) {
                updateManager.showUpdateDialog(updateInfo);
            }

            @Override
            public void onNoUpdate() {
                Log.i(TAG, "当前已是最新版本");
            }

            @Override
            public void onError(String message) {
                Log.e(TAG, "检查更新失败: " + message);
            }

            @Override
            public void onDownloadProgress(int progress) {
                Log.d(TAG, "下载进度: " + progress + "%");
            }

            @Override
            public void onDownloadComplete(File file) {
                Log.i(TAG, "下载完成: " + file.getAbsolutePath());
            }
        });

        cardVerificationManager = new CardVerificationManager(this);

        cardVerificationManager.checkAndVerify(() -> {
            runOnUiThread(() -> {
                binding = ActivityMainBinding.inflate(getLayoutInflater());
                setContentView(binding.getRoot());

                initializeApp();

                if (updateManager.shouldCheckUpdate()) {
                    updateManager.checkForUpdates();
                }

                updateManager.startBackgroundCheck();
            });
        });
    }

    private void initializeApp() {
        Shizuku.addRequestPermissionResultListener(ShizukuHelper.REQUEST_PERMISSION_RESULT_LISTENER);

        requestShizukuPermission();

        requestNotificationPermission();

        BottomNavigationView navView = findViewById(R.id.nav_view);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_settings)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupWithNavController(binding.navView, navController);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Shizuku.removeRequestPermissionResultListener(ShizukuHelper.REQUEST_PERMISSION_RESULT_LISTENER);

        if (updateManager != null) {
            updateManager.destroy();
        }
        if (cardVerificationManager != null) {
            cardVerificationManager.destroy();
        }
    }

    private void requestShizukuPermission() {
        if (ShizukuHelper.isShizukuAvailable()) {
            ShizukuHelper.requestShizukuPermission(granted -> {
                if (granted) {
                    Log.d(TAG, "Shizuku permission granted");
                } else {
                    Log.d(TAG, "Shizuku permission denied");
                }
            });
        } else {
            Log.d(TAG, "Shizuku is not available");
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            boolean notificationsEnabled = preferencesManager.isPushNotificationsEnabled();

            if (notificationsEnabled) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "Notification permission already granted");
                } else {
                    MessageDialog.show("通知权限",
                            "为了及时推送重要信息,需要您授予通知权限。\n\n您可以随时在设置中关闭通知。",
                            "授予", "暂不"
                    ).setOkButtonClickListener((dialog, v) -> {
                        requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
                        return false;
                    }).setCancelButtonClickListener((dialog, v) -> {
                        preferencesManager.setPushNotificationsEnabled(false);
                        return false;
                    });
                }
            }
        }
    }

    public void recheckNotificationPermission() {
        requestNotificationPermission();
    }
}