package com.viqitos.tools.ui.systemoptimize;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.chip.Chip;
import com.kongzue.dialogx.dialogs.BottomMenu;
import com.kongzue.dialogx.dialogs.MessageDialog;
import com.kongzue.dialogx.dialogs.PopTip;
import com.kongzue.dialogx.dialogs.WaitDialog;
import com.viqitos.tools.R;
import com.viqitos.tools.utils.AnimationUtils;
import com.viqitos.tools.utils.ShizukuHelper;

import java.util.ArrayList;
import java.util.List;

public class SystemOptimizeActivity extends AppCompatActivity {

    private static final String TAG = "SystemOptimizeActivity";
    private RecyclerView recyclerOptimizations;
    private OptimizationAdapter adapter;
    private Handler mainHandler;
    private ConfigurationMonitor configMonitor;
    private boolean isMonitoring = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_system_optimize);

        mainHandler = new Handler(Looper.getMainLooper());
        configMonitor = new ConfigurationMonitor();
        
        setupViews();
        checkShizukuPermission();
        startConfigurationMonitoring();
    }

    private void setupViews() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("系统设置项优化");
        }

        recyclerOptimizations = findViewById(R.id.recycler_optimizations);
        recyclerOptimizations.setLayoutManager(new LinearLayoutManager(this));

        Chip chipPerformance = findViewById(R.id.chip_performance);
        Chip chipBattery = findViewById(R.id.chip_battery);
        Chip chipSystem = findViewById(R.id.chip_system);
        Chip chipDisplay = findViewById(R.id.chip_display);

        setupOptimizationList();
        chipPerformance.setOnClickListener(v -> filterOptimizations("性能优化"));
        chipBattery.setOnClickListener(v -> filterOptimizations("省电优化"));
        chipSystem.setOnClickListener(v -> filterOptimizations("系统优化"));
        chipDisplay.setOnClickListener(v -> filterOptimizations("显示优化"));
        recyclerOptimizations.post(() -> AnimationUtils.expressiveScaleIn(recyclerOptimizations));
    }

    private void checkShizukuPermission() {
        if (!ShizukuHelper.isShizukuAvailable()) {
            MessageDialog.show("需要Shizuku权限",
                    "此功能需要Shizuku服务才能正常工作。\n\n请确保：\n1. 已安装Shizuku应用\n2. Shizuku服务正在运行\n3. 已授予本应用Shizuku权限",
                    "我知道了", "退出"
            ).setOkButtonClickListener((dialog, v) -> {
                ShizukuHelper.requestShizukuPermission(granted -> {
                    if (!granted) {
                        mainHandler.post(() -> PopTip.show("未授予Shizuku权限"));
                    }
                });
                return false;
            }).setCancelButtonClickListener((dialog, v) -> {
                finish();
                return false;
            });
        }
    }

    private void setupOptimizationList() {
        List<OptimizationItem> items = new ArrayList<>();
        items.add(new OptimizationItem(
                "预加载优化",
                "优化系统进程预加载机制，提升启动速度",
                "性能优化",
                "settings put global zygote_process_preload 1",
                "settings put global zygote_process_preload 0"
        ));

        items.add(new OptimizationItem(
                "关闭系统通知",
                "关闭系统更新通知，减少干扰",
                "系统优化",
                "settings put system bbk_update_notice 0",
                "settings put system bbk_update_notice 1"
        ));

        items.add(new OptimizationItem(
                "开启Ai加速引擎",
                "启用AI智能加速，提升系统性能",
                "性能优化",
                "settings put system ai_turbo_enabled 1",
                "settings put system ai_turbo_enabled 0"
        ));

        items.add(new OptimizationItem(
                "Doze优化",
                "启用Doze模式，优化后台耗电",
                "省电优化",
                "dumpsys deviceidle enable",
                "dumpsys deviceidle disable"
        ));

        items.add(new OptimizationItem(
                "开启编译增强引擎",
                "启用ART编译器优化，提升应用性能",
                "性能优化",
                "settings put global artpp_enabled 1",
                "settings put global artpp_enabled 0"
        ));

        items.add(new OptimizationItem(
                "刷新率匹配模式",
                "设置屏幕刷新率匹配模式",
                "显示优化",
                "settings put global match_content_frame_rate 1",
                "settings put global match_content_frame_rate 0"
        ));

        adapter = new OptimizationAdapter(items, this::onOptimizationItemClick);
        recyclerOptimizations.setAdapter(adapter);
    }

    private void filterOptimizations(String category) {
        if (adapter != null) {
            adapter.filterByCategory(category);
            PopTip.show("显示" + category);
        }
    }

    private void onOptimizationItemClick(OptimizationItem item) {
        BottomMenu.show(new String[]{
                "应用优化",
                "恢复默认",
                "取消"
        }).setOnMenuItemClickListener((dialog, text, index) -> {
            switch (index) {
                case 0:
                    confirmAndApplyOptimization(item, true);
                    break;
                case 1:
                    confirmAndApplyOptimization(item, false);
                    break;
                case 2:
                    break;
            }
            return false;
        });
    }

    private void confirmAndApplyOptimization(OptimizationItem item, boolean apply) {
        String action = apply ? "应用优化" : "恢复默认";
        String command = apply ? item.enableCommand : item.disableCommand;

        MessageDialog.show("确认" + action,
                "即将执行以下操作：\n\n" +
                        "名称：" + item.title + "\n" +
                        "说明：" + item.description + "\n" +
                        "类型：" + item.category + "\n\n" +
                        "⚠️ 此操作将修改系统设置，请确认是否继续？",
                "确认", "取消"
        ).setOkButtonClickListener((dialogInterface, v) -> {
            executeOptimization(command, item.title, action);
            return false;
        });
    }

    private void executeOptimization(String command, String title, String action) {
        WaitDialog.show("正在" + action + "...");
        configMonitor.recordConfigChange(title, action);

        ShizukuHelper.executeShellCommand(command, result -> {
            mainHandler.post(() -> {
                WaitDialog.dismiss();

                if (result != null && !result.contains("Error") && !result.contains("Permission denied")) {
                    MessageDialog.show(action + "成功",
                            title + " " + action + "成功！\n\n" +
                                    "执行结果：\n" + (result.isEmpty() ? "命令执行完成" : result),
                            "确定"
                    );
                } else {
                    MessageDialog.show(action + "失败",
                            title + " " + action + "失败！\n\n" +
                                    "错误信息：\n" + result,
                            "确定"
                    );
                }
            });
        });
    }

    private void startConfigurationMonitoring() {
        if (!isMonitoring) {
            configMonitor.startMonitoring(this);
            isMonitoring = true;
            Log.i(TAG, "配置监控已启动");
        }
    }

    private void stopConfigurationMonitoring() {
        if (isMonitoring) {
            configMonitor.stopMonitoring(this);
            isMonitoring = false;
            Log.i(TAG, "配置监控已停止");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopConfigurationMonitoring();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private class ConfigurationMonitor {
        private BroadcastReceiver settingsReceiver;
        private List<String> configChangeLog;
        private static final int MAX_LOG_SIZE = 100;

        public ConfigurationMonitor() {
            configChangeLog = new ArrayList<>();
        }

        public void startMonitoring(Context context) {
            settingsReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    String action = intent.getAction();
                    if (Intent.ACTION_CONFIGURATION_CHANGED.equals(action)) {
                        detectUnauthorizedChanges();
                    }
                }
            };

            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_CONFIGURATION_CHANGED);
            context.registerReceiver(settingsReceiver, filter);
            startPeriodicCheck();
        }

        public void stopMonitoring(Context context) {
            if (settingsReceiver != null) {
                try {
                    context.unregisterReceiver(settingsReceiver);
                } catch (Exception e) {
                    Log.e(TAG, "停止监控失败: " + e.getMessage());
                }
            }
            stopPeriodicCheck();
        }

        public void recordConfigChange(String title, String action) {
            String log = System.currentTimeMillis() + ": " + title + " - " + action;
            configChangeLog.add(log);
            if (configChangeLog.size() > MAX_LOG_SIZE) {
                configChangeLog.remove(0);
            }
            
            Log.d(TAG, "配置变更记录: " + log);
        }

        private void detectUnauthorizedChanges() {
            ShizukuHelper.executeShellCommand("dumpsys activity top", result -> {
                if (result != null && !result.contains("SystemOptimizeActivity")) {
                    Log.w(TAG, "检测到可能的未授权配置变更");
                    mainHandler.post(() -> {
                        PopTip.show("检测到系统配置变更");
                    });
                }
            });
        }

        private void startPeriodicCheck() {
            mainHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (isMonitoring) {
                        performSecurityCheck();
                        mainHandler.postDelayed(this, 30000);
                    }
                }
            }, 30000);
        }

        private void stopPeriodicCheck() {
            mainHandler.removeCallbacksAndMessages(null);
        }

        private void performSecurityCheck() {
            verifyConfigIntegrity();
        }

        private void verifyConfigIntegrity() {
            String[] criticalSettings = {
                    "settings get global zygote_process_preload",
                    "settings get system bbk_update_notice",
                    "settings get system ai_turbo_enabled",
                    "settings get global artpp_enabled",
                    "settings get global match_content_frame_rate"
            };

            for (String cmd : criticalSettings) {
                ShizukuHelper.executeShellCommand(cmd, result -> {
                    if (result != null && !result.isEmpty()) {
                        Log.d(TAG, "配置验证: " + cmd + " = " + result.trim());
                    }
                });
            }
        }
    }

    public static class OptimizationItem {
        public String title;
        public String description;
        public String category;
        public String enableCommand;
        public String disableCommand;

        public OptimizationItem(String title, String description, String category,
                                String enableCommand, String disableCommand) {
            this.title = title;
            this.description = description;
            this.category = category;
            this.enableCommand = enableCommand;
            this.disableCommand = disableCommand;
        }
    }
}
