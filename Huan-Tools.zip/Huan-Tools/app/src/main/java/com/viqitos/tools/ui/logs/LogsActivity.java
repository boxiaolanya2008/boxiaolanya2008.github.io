package com.viqitos.tools.ui.logs;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.viqitos.tools.R;
import com.viqitos.tools.utils.CrashLogManager;

public class LogsActivity extends AppCompatActivity {
    private TextView logsTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logs);

        setupViews();
        loadLogs();
    }

    private void setupViews() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("日志查看");
        }

        logsTextView = findViewById(R.id.logs_text);
    }

    private void loadLogs() {
        String logs = CrashLogManager.getInstance(this).getAllCrashLogs();
        if (logs.isEmpty()) {
            logsTextView.setText("暂无日志记录");
        } else {
            logsTextView.setText(logs);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
