package com.viqitos.tools.ui.settings;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.kongzue.dialogx.dialogs.MessageDialog;
import com.kongzue.dialogx.dialogs.PopTip;
import com.viqitos.tools.MainActivity;
import com.viqitos.tools.databinding.FragmentSettingsBinding;
import com.viqitos.tools.utils.AnimationUtils;
import com.viqitos.tools.utils.UpdateManager;

import java.io.File;

public class SettingsFragment extends Fragment {

    private FragmentSettingsBinding binding;
    private UpdateManager updateManager;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        SettingsViewModel settingsViewModel =
                new ViewModelProvider(this).get(SettingsViewModel.class);

        binding = FragmentSettingsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        updateManager = new UpdateManager(requireContext());
        updateManager.setUpdateCallback(new UpdateManager.UpdateCallback() {
            @Override
            public void onUpdateAvailable(UpdateManager.UpdateInfo updateInfo) {
                updateManager.showUpdateDialog(updateInfo);
            }

            @Override
            public void onNoUpdate() {
                PopTip.show("当前已是最新版本");
            }

            @Override
            public void onError(String message) {
                PopTip.show("检查更新失败: " + message);
            }

            @Override
            public void onDownloadProgress(int progress) {
            }

            @Override
            public void onDownloadComplete(File file) {
            }
        });

        LinearLayout btnAboutApp = binding.btnAboutApp;
        LinearLayout btnCheckUpdates = binding.btnCheckUpdates;
        LinearLayout btnFeedback = binding.btnFeedback;

        root.post(() -> {
            AnimationUtils.expressiveScaleIn(btnAboutApp);
        });

        setListItemAnimation(btnAboutApp, "关于应用", "Viqitos Tools v1.0\n\n一款基于 Material Design 3 Expressive 设计的 Android 工具应用。\n\n集成 Shizuku 实现系统级操作。");

        btnCheckUpdates.setOnClickListener(v -> {
            AnimationUtils.expressiveRipple(btnCheckUpdates);
            updateManager.checkForUpdates(true);
        });

        setListItemAnimation(btnFeedback, "意见反馈", "感谢您的反馈！请通过邮件联系我们。");

        return root;
    }

    private void setListItemAnimation(LinearLayout listItem, String title, String message) {
        listItem.setOnClickListener(v -> {
            AnimationUtils.expressiveRipple(listItem);

            MessageDialog.show(title, message, "确定");
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (updateManager != null) {
            updateManager.destroy();
        }
        binding = null;
    }
}
