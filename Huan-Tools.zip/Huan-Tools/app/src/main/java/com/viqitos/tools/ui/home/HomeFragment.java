package com.viqitos.tools.ui.home;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.kongzue.dialogx.dialogs.MessageDialog;
import com.kongzue.dialogx.dialogs.PopTip;
import com.viqitos.tools.R;
import com.viqitos.tools.databinding.FragmentHomeBinding;
import com.viqitos.tools.utils.AnimationUtils;
import com.viqitos.tools.utils.ShizukuHelper;
import java.util.ArrayList;
import java.util.List;
import rikka.shizuku.Shizuku;

public class HomeFragment
    extends Fragment
    implements ToolAdapter.OnToolClickListener {

    private FragmentHomeBinding binding;
    private HomeViewModel homeViewModel;
    private final List<ToolItem> toolItems = new ArrayList<>();
    private ToolAdapter toolAdapter;

    @Override
    public View onCreateView(
        @NonNull LayoutInflater inflater,
        ViewGroup container,
        Bundle savedInstanceState
    ) {
        homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(
        @NonNull View view,
        @Nullable Bundle savedInstanceState
    ) {
        super.onViewCreated(view, savedInstanceState);

        setupShizukuStatus();
        setupRecyclerView();
        setupToolCards();
        setupQuickActions();
        playEnterAnimations();
    }

    private void setupShizukuStatus() {
        updateShizukuStatus();

        binding.btnShizukuAction.setOnClickListener(v -> {
            AnimationUtils.animateButtonPress(binding.btnShizukuAction);

            if (ShizukuHelper.isShizukuAvailable()) {
                ShizukuHelper.requestShizukuPermission(granted -> {
                    requireActivity().runOnUiThread(() -> {
                        if (granted) {
                            PopTip.show(getString(R.string.shizuku_connected));
                        } else {
                            PopTip.show(
                                getString(R.string.shizuku_permission_denied)
                            );
                        }
                        updateShizukuStatus();
                    });
                });
            } else {
                MessageDialog.show(
                    "Shizuku 未运行",
                    "请先启动 Shizuku 服务。\n\n您可以通过 ADB 或 Root 方式启动 Shizuku。",
                    getString(R.string.ok)
                );
            }
        });
        binding.cardShizukuStatus.setOnClickListener(v -> {
            AnimationUtils.expressiveRipple(binding.cardShizukuStatus);
            updateShizukuStatus();
        });
    }

    private void updateShizukuStatus() {
        if (ShizukuHelper.isShizukuAvailable()) {
            int permission = Shizuku.checkSelfPermission();
            if (permission == PackageManager.PERMISSION_GRANTED) {
                binding.textShizukuStatus.setText(R.string.shizuku_connected);
                binding.btnShizukuAction.setText(R.string.refresh);
            } else {
                binding.textShizukuStatus.setText(
                    R.string.shizuku_permission_denied
                );
                binding.btnShizukuAction.setText(R.string.authorize);
            }
        } else {
            binding.textShizukuStatus.setText(R.string.shizuku_not_running);
            binding.btnShizukuAction.setText(R.string.refresh);
        }
    }

    private void setupToolCards() {
        toolItems.clear();
        toolItems.add(
            new ToolItem(
                R.drawable.ic_dashboard_black_24dp,
                getString(R.string.tool_app_manager),
                getString(R.string.tool_app_manager_desc),
                "app_manager"
            )
        );
        toolItems.add(
            new ToolItem(
                R.drawable.ic_lock,
                getString(R.string.tool_permission),
                getString(R.string.tool_permission_desc),
                "permission"
            )
        );
        toolItems.add(
            new ToolItem(
                R.drawable.ic_dashboard_black_24dp,
                getString(R.string.tool_thermal_query),
                getString(R.string.tool_thermal_query_desc),
                "thermal_query"
            )
        );
        toolItems.add(
            new ToolItem(
                R.drawable.ic_dashboard_black_24dp,
                getString(R.string.tool_power_info),
                getString(R.string.tool_power_info_desc),
                "power_info"
            )
        );
        toolItems.add(
            new ToolItem(
                R.drawable.ic_dashboard_black_24dp,
                getString(R.string.tool_system_optimize),
                getString(R.string.tool_system_optimize_desc),
                "system_optimize"
            )
        );

        if (toolAdapter != null) {
            toolAdapter.notifyDataSetChanged();
        }
    }

    private void setupRecyclerView() {
        toolAdapter = new ToolAdapter(requireContext(), toolItems, this);
        binding.recyclerTools.setLayoutManager(
            new GridLayoutManager(requireContext(), 2)
        );
        binding.recyclerTools.setAdapter(toolAdapter);
        binding.recyclerTools.setHasFixedSize(true);
    }

    @Override
    public void onToolClick(ToolItem toolItem) {
        Intent intent;
        switch (toolItem.action) {
            case "app_manager":
                intent = new Intent(
                    requireContext(),
                    com.viqitos.tools.ui.appmanager.AppManagerActivity.class
                );
                break;
            case "permission":
                intent = new Intent(
                    requireContext(),
                    com.viqitos.tools.ui.permission
                        .PermissionManagerActivity.class
                );
                break;
            case "thermal_query":
                intent = new Intent(
                    requireContext(),
                    com.viqitos.tools.ui.thermal.ThermalQueryActivity.class
                );
                break;
            case "power_info":
                intent = new Intent(
                    requireContext(),
                    com.viqitos.tools.ui.powerinfo.PowerInfoActivity.class
                );
                break;
            case "system_optimize":
                intent = new Intent(
                    requireContext(),
                    com.viqitos.tools.ui.systemoptimize.SystemOptimizeActivity.class
                );
                break;
            default:
                return;
        }
        startActivity(intent);
    }

    private void setupToolCard(
        MaterialCardView card,
        String title,
        String message
    ) {
        card.setOnClickListener(v -> {
            AnimationUtils.expressiveRipple(card);
            MessageDialog.show(title, message, getString(R.string.ok));
        });
    }

    private void setupQuickActions() {
        binding.btnClearCache.setOnClickListener(v -> {
            AnimationUtils.expressiveRipple(binding.btnClearCache);
            clearAllCache();
        });

        binding.btnViewLogs.setOnClickListener(v -> {
            AnimationUtils.expressiveRipple(binding.btnViewLogs);
            Intent intent = new Intent(
                requireContext(),
                com.viqitos.tools.ui.logs.LogsActivity.class
            );
            startActivity(intent);
        });
    }

    private void clearAllCache() {
        MessageDialog.show(
            "清理缓存",
            "确定要清理所有应用缓存吗？\n\n这将需要Shizuku权限。",
            "确定",
            "取消"
        ).setOkButtonClickListener((dialog, v) -> {
            if (!ShizukuHelper.isShizukuAvailable()) {
                PopTip.show("需要Shizuku权限");
                return false;
            }

            com.kongzue.dialogx.dialogs.WaitDialog.show("正在清理缓存...");
            ShizukuHelper.executeShellCommand("pm trim-caches 999G", result -> {
                requireActivity().runOnUiThread(() -> {
                    com.kongzue.dialogx.dialogs.WaitDialog.dismiss();
                    PopTip.show("缓存清理完成");
                });
            });
            return false;
        });
    }

    private void playEnterAnimations() {
        binding
            .getRoot()
            .post(() -> {
                AnimationUtils.expressiveScaleIn(binding.cardShizukuStatus);

                binding.cardShizukuStatus.postDelayed(
                    () ->
                        AnimationUtils.expressiveScaleIn(binding.recyclerTools),
                    100
                );

                binding.recyclerTools.postDelayed(
                    () ->
                        AnimationUtils.expressiveScaleIn(binding.btnClearCache),
                    80
                );
            });
    }

    @Override
    public void onResume() {
        super.onResume();
        updateShizukuStatus();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
