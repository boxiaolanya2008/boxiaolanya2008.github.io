package com.viqitos.tools.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferencesManager {

    private static final String PREFS_NAME = "ViqitosToolsPrefs";

    private static final String KEY_PUSH_NOTIFICATIONS = "push_notifications_enabled";
    private static final String KEY_FIRST_LAUNCH = "first_launch";
    private static final String KEY_LAST_UPDATE_CHECK = "last_update_check";

    private final SharedPreferences preferences;
    private static PreferencesManager instance;

    private PreferencesManager(Context context) {
        preferences = context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized PreferencesManager getInstance(Context context) {
        if (instance == null) {
            instance = new PreferencesManager(context);
        }
        return instance;
    }

    public boolean isPushNotificationsEnabled() {
        return preferences.getBoolean(KEY_PUSH_NOTIFICATIONS, true);
    }

    public void setPushNotificationsEnabled(boolean enabled) {
        preferences.edit().putBoolean(KEY_PUSH_NOTIFICATIONS, enabled).apply();
    }

    public boolean isFirstLaunch() {
        return preferences.getBoolean(KEY_FIRST_LAUNCH, true);
    }

    public void setFirstLaunch(boolean firstLaunch) {
        preferences.edit().putBoolean(KEY_FIRST_LAUNCH, firstLaunch).apply();
    }

    public long getLastUpdateCheckTime() {
        return preferences.getLong(KEY_LAST_UPDATE_CHECK, 0);
    }

    public void setLastUpdateCheckTime(long timestamp) {
        preferences.edit().putLong(KEY_LAST_UPDATE_CHECK, timestamp).apply();
    }

    public void clearAll() {
        preferences.edit().clear().apply();
    }
}
