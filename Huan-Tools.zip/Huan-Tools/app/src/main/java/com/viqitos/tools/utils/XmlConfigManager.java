package com.viqitos.tools.utils;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class XmlConfigManager {

    private static final String TAG = "XmlConfigManager";
    private static final String XML_FILE_NAME = "fuelsummary_uc.xml";

    private static final String EXPORT_DIR_PATH = "/sdcard/";
    private static final String EXPORT_FILE_NAME = "fuelsummary_uc.xml";

    private Context context;
    private List<XmlConfigGroup> currentConfig;

    public XmlConfigManager(Context context) {
        this.context = context;
    }

    public static class XmlConfigItem {
        public String name;
        public String value;
        public String type;
        public String description;

        public XmlConfigItem(String name, String value, String type, String description) {
            this.name = name;
            this.value = value;
            this.type = type;
            this.description = description;
        }
    }

    public static class XmlConfigGroup {
        public String name;
        public List<XmlConfigItem> items;

        public XmlConfigGroup(String name, List<XmlConfigItem> items) {
            this.name = name;
            this.items = items;
        }
    }

    public String readXmlFile() {
        try {
            InputStream inputStream = context.getAssets().open(XML_FILE_NAME);
            byte[] buffer = new byte[inputStream.available()];
            inputStream.read(buffer);
            inputStream.close();
            return new String(buffer, "UTF-8");
        } catch (Exception e) {
            Log.e(TAG, "读取XML文件失败: " + e.getMessage(), e);
            return null;
        }
    }

    public List<XmlConfigGroup> parseXmlConfig() {
        String xmlContent = readXmlFile();
        if (xmlContent == null) {
            return new ArrayList<>();
        }

        try {
            return parseRealXmlConfig(xmlContent);
        } catch (Exception e) {
            Log.e(TAG, "解析XML配置失败: " + e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    private List<XmlConfigGroup> parseRealXmlConfig(String xmlContent) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new ByteArrayInputStream(xmlContent.getBytes()));

        List<XmlConfigGroup> groups = new ArrayList<>();

        NodeList normalParams = doc.getElementsByTagName("normal_params");
        if (normalParams.getLength() > 0) {
            List<XmlConfigItem> items = new ArrayList<>();
            NodeList childNodes = normalParams.item(0).getChildNodes();

            for (int i = 0; i < childNodes.getLength(); i++) {
                Node node = childNodes.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;

                    if (element.getTagName().equals("integer")) {
                        String name = element.getAttribute("name");
                        String value = element.getTextContent();
                        items.add(new XmlConfigItem(name, value, "integer", getDescription(name)));
                    } else if (element.getTagName().equals("item")) {
                        String name = element.getAttribute("name");
                        String value = element.getTextContent();
                        items.add(new XmlConfigItem(name, value, "string", getDescription(name)));
                    } else if (element.getTagName().equals("integer-array")) {
                        String value = element.getTextContent();
                        items.add(new XmlConfigItem("board_thermal_array", value, "integer-array", "主板温度阈值数组"));
                    }
                }
            }
            groups.add(new XmlConfigGroup("普通参数", items));
        }

        NodeList driverParams = doc.getElementsByTagName("driver_params");
        if (driverParams.getLength() > 0) {
            List<XmlConfigItem> items = new ArrayList<>();
            NodeList childNodes = driverParams.item(0).getChildNodes();

            for (int i = 0; i < childNodes.getLength(); i++) {
                Node node = childNodes.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;

                    if (element.getTagName().equals("integer")) {
                        String name = element.getAttribute("name");
                        String value = element.getTextContent();
                        items.add(new XmlConfigItem(name, value, "integer", getDescription(name)));
                    }
                }
            }
            groups.add(new XmlConfigGroup("驱动参数", items));
        }

        NodeList chargingParams = doc.getElementsByTagName("charging_params");
        if (chargingParams.getLength() > 0) {
            List<XmlConfigItem> items = new ArrayList<>();
            NodeList childNodes = chargingParams.item(0).getChildNodes();

            for (int i = 0; i < childNodes.getLength(); i++) {
                Node node = childNodes.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;

                    if (element.getTagName().equals("item")) {
                        String name = element.getAttribute("name");
                        String value = element.getTextContent();
                        items.add(new XmlConfigItem(name, value, "string", getDescription(name)));
                    } else if (element.getTagName().equals("integer-array")) {
                        String value = element.getTextContent();
                        String arrayName = "charging_array_" + i;
                        items.add(new XmlConfigItem(arrayName, value, "integer-array", "充电参数数组 (" + element.getAttribute("name") + ")"));
                    }
                }
            }
            groups.add(new XmlConfigGroup("充电参数", items));
        }

        NodeList batteryCurve = doc.getElementsByTagName("battery_curve");
        if (batteryCurve.getLength() > 0) {
            List<XmlConfigItem> items = new ArrayList<>();
            NodeList childNodes = batteryCurve.item(0).getChildNodes();

            for (int i = 0; i < childNodes.getLength(); i++) {
                Node node = childNodes.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;

                    if (element.getTagName().equals("item")) {
                        String name = element.getAttribute("name");
                        String value = element.getTextContent();
                        items.add(new XmlConfigItem(name, value, "string", getDescription(name)));
                    } else if (element.getTagName().equals("hex-array")) {
                        String value = element.getTextContent();
                        items.add(new XmlConfigItem("fg_profile_hex", value, "string", "电池曲线十六进制数据"));
                    }
                }
            }
            groups.add(new XmlConfigGroup("电池曲线", items));
        }

        return groups;
    }

    private String getDescription(String name) {
        switch (name) {
            case "pw_standby_capacity":
                return "待机保持电量百分比";
            case "pw_standby_seconds":
                return "待机保持时间(秒)";
            case "pw_drop_levels":
                return "电量下降级别";
            case "vddmin_seconds":
                return "最低电压持续时间(秒)";
            case "fcc_too_low":
                return "电池容量过低警告值(毫安时)";
            case "sf_shutdown_vbat":
                return "软件自动关机电压(毫伏)";
            case "hw_shutdown_vbat":
                return "硬件自动关机电压(毫伏)";
            case "full_drop_seconds":
                return "满电后开始掉电时间(秒)";
            case "low_drop_seconds":
                return "低电量掉电时间(秒)";
            case "plug_interval_seconds":
                return "充电器检测间隔(秒)";
            case "unconditional_report":
                return "强制上报数据(0=关闭,1=开启)";
            case "uspace_cycle":
                return "用户空间循环次数";
            case "board_thermal_thresholds":
                return "主板温度阈值设置";
            case "vivo,capacity-mAh":
                return "电池标称容量(毫安时)";
            case "vivo,normal-tc-data":
                return "普通温控数据";
            case "qcom,fg-profile-data":
                return "高通电量计配置数据";
            default:
                return "配置参数";
        }
    }

    public String exportConfigToFile() {
        try {
            List<XmlConfigGroup> config = getCurrentConfig();
            if (config == null || config.isEmpty()) {
                Log.e(TAG, "当前配置为空");
                return null;
            }

            String xmlContent = readXmlFile();
            if (xmlContent == null || xmlContent.isEmpty()) {
                Log.e(TAG, "无法读取原始配置文件");
                return null;
            }

            File exportFile = new File(EXPORT_DIR_PATH, EXPORT_FILE_NAME);

            String formattedXml = buildXmlFromConfig(config, xmlContent);

            FileOutputStream fos = new FileOutputStream(exportFile);
            OutputStreamWriter writer = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
            writer.write(formattedXml);
            writer.flush();
            writer.close();
            fos.close();

            Log.d(TAG, "配置导出成功: " + exportFile.getAbsolutePath());
            return exportFile.getAbsolutePath();

        } catch (Exception e) {
            Log.e(TAG, "导出配置失败: " + e.getMessage(), e);
            return null;
        }
    }

    private String buildXmlFromConfig(List<XmlConfigGroup> config, String originalXml) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new ByteArrayInputStream(originalXml.getBytes(StandardCharsets.UTF_8)));

            for (XmlConfigGroup group : config) {
                updateGroupInXml(doc, group);
            }

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");

            java.io.StringWriter writer = new java.io.StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
            return writer.toString();

        } catch (Exception e) {
            Log.e(TAG, "构建 XML 失败: " + e.getMessage());
            return originalXml;
        }
    }

    private void updateGroupInXml(Document doc, XmlConfigGroup group) {
        String tagName = getTagNameForGroup(group.name);
        if (tagName == null) {
            return;
        }

        NodeList groupNodes = doc.getElementsByTagName(tagName);
        if (groupNodes.getLength() == 0) {
            return;
        }

        Node groupNode = groupNodes.item(0);
        NodeList childNodes = groupNode.getChildNodes();

        for (int i = 0; i < childNodes.getLength(); i++) {
            Node node = childNodes.item(i);
            if (node.getNodeType() != Node.ELEMENT_NODE) {
                continue;
            }

            Element element = (Element) node;
            String elementName = element.getTagName();

            if (elementName.equals("integer") || elementName.equals("item")) {
                String attrName = element.getAttribute("name");
                if (attrName != null && !attrName.isEmpty()) {
                    for (XmlConfigItem item : group.items) {
                        if (item.name.equals(attrName)) {
                            element.setTextContent(item.value);
                            break;
                        }
                    }
                }
            } else if (elementName.equals("integer-array") || elementName.equals("hex-array")) {
                updateArrayElement(element, group.items, elementName, i, group.name);
            }
        }
    }

    private void updateArrayElement(Element element, List<XmlConfigItem> items, String arrayType, int nodeIndex, String groupName) {
        String targetArrayName = null;

        if (groupName.equals("充电参数") && arrayType.equals("integer-array")) {
            targetArrayName = "charging_array_" + nodeIndex;
        } else if (groupName.equals("普通参数") && arrayType.equals("integer-array")) {
            targetArrayName = "board_thermal_array";
        } else if (arrayType.equals("hex-array")) {
            targetArrayName = "fg_profile_hex";
        }

        if (targetArrayName == null) {
            Log.w(TAG, "无法确定数组名称: arrayType=" + arrayType + ", nodeIndex=" + nodeIndex + ", group=" + groupName);
            return;
        }

        for (XmlConfigItem item : items) {
            if (item.name.equals(targetArrayName)) {
                element.setTextContent(item.value);
                Log.d(TAG, "更新数组元素: " + targetArrayName + " = " + item.value);
                return;
            }
        }

        Log.d(TAG, "未找到配置项: " + targetArrayName + "，保持原值");
    }

    private String getTagNameForGroup(String groupName) {
        switch (groupName) {
            case "普通参数":
                return "normal_params";
            case "驱动参数":
                return "driver_params";
            case "充电参数":
                return "charging_params";
            case "电池曲线":
                return "battery_curve";
            default:
                return null;
        }
    }

    public boolean importConfigFromFile(String filePath) {
        try {
            File file = new File(filePath);
            if (!file.exists() || !file.canRead()) {
                Log.e(TAG, "文件不存在或无法读取: " + filePath);
                return false;
            }

            FileInputStream fis = new FileInputStream(file);
            byte[] buffer = new byte[(int) file.length()];
            fis.read(buffer);
            fis.close();

            String xmlContent = new String(buffer, StandardCharsets.UTF_8);

            if (!validateXmlFormat(xmlContent)) {
                Log.e(TAG, "导入的文件不是有效的 fuelsummary_uc.xml 格式");
                return false;
            }

            List<XmlConfigGroup> importedConfig = parseRealXmlConfig(xmlContent);
            if (importedConfig == null || importedConfig.isEmpty()) {
                Log.e(TAG, "导入的配置为空或格式错误");
                return false;
            }

            currentConfig = importedConfig;
            Log.d(TAG, "配置导入成功: " + filePath);
            return true;

        } catch (Exception e) {
            Log.e(TAG, "导入配置失败: " + e.getMessage(), e);
            return false;
        }
    }

    private boolean validateXmlFormat(String xmlContent) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new ByteArrayInputStream(xmlContent.getBytes(StandardCharsets.UTF_8)));

            Element root = doc.getDocumentElement();
            if (!"CONFIG".equals(root.getTagName())) {
                Log.e(TAG, "根元素不是 CONFIG");
                return false;
            }

            NodeList normalParams = doc.getElementsByTagName("normal_params");
            NodeList driverParams = doc.getElementsByTagName("driver_params");
            NodeList chargingParams = doc.getElementsByTagName("charging_params");
            NodeList batteryCurve = doc.getElementsByTagName("battery_curve");

            boolean hasRequiredElements = normalParams.getLength() > 0 ||
                                         driverParams.getLength() > 0 ||
                                         chargingParams.getLength() > 0 ||
                                         batteryCurve.getLength() > 0;

            if (!hasRequiredElements) {
                Log.e(TAG, "缺少必要的配置节点");
                return false;
            }

            return true;

        } catch (Exception e) {
            Log.e(TAG, "XML 格式验证失败: " + e.getMessage());
            return false;
        }
    }

    public List<XmlConfigGroup> getCurrentConfig() {
        if (currentConfig == null) {
            currentConfig = parseXmlConfig();
        }
        return currentConfig;
    }

    public void refreshConfig() {
        currentConfig = parseXmlConfig();
    }

    public String getExportDirPath() {
        return EXPORT_DIR_PATH;
    }
}
