package com.viqitos.tools;

import android.app.Application;
import android.os.Build;

import com.google.android.material.color.DynamicColors;
import com.kongzue.dialogx.DialogX;

public class ViqitosApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            DynamicColors.applyToActivitiesIfAvailable(this);
        }

        DialogX.init(this);
        DialogX.globalTheme = DialogX.THEME.AUTO;
        DialogX.autoShowInputKeyboard = true;
        DialogX.onlyOnePopTip = true;
    }
}