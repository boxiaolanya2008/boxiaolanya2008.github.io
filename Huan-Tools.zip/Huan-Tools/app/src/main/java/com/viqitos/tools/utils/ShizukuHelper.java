package com.viqitos.tools.utils;

import android.content.pm.PackageManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuRemoteProcess;

public class ShizukuHelper {
    private static final String TAG = "ShizukuHelper";
    private static final int REQUEST_CODE_PERMISSION = 1001;

    public interface ShizukuPermissionCallback {
        void onPermissionResult(boolean granted);
    }

    public interface ShellCommandCallback {
        void onResult(String result);
    }

    private static ShizukuPermissionCallback permissionCallback;

    public static void requestShizukuPermission(ShizukuPermissionCallback callback) {
        permissionCallback = callback;

        if (Shizuku.isPreV11()) {
            Log.e(TAG, "Shizuku version is too old");
            if (permissionCallback != null) {
                permissionCallback.onPermissionResult(false);
            }
            return;
        }

        int permission = Shizuku.checkSelfPermission();
        if (permission == PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "Shizuku permission already granted");
            if (permissionCallback != null) {
                permissionCallback.onPermissionResult(true);
            }
        } else if (Shizuku.shouldShowRequestPermissionRationale()) {
            Log.d(TAG, "Shizuku permission denied permanently");
            if (permissionCallback != null) {
                permissionCallback.onPermissionResult(false);
            }
        } else {
            Log.d(TAG, "Requesting Shizuku permission");
            Shizuku.requestPermission(REQUEST_CODE_PERMISSION);
        }
    }

    public static final Shizuku.OnRequestPermissionResultListener REQUEST_PERMISSION_RESULT_LISTENER = 
        new Shizuku.OnRequestPermissionResultListener() {
            @Override
            public void onRequestPermissionResult(int requestCode, int grantResult) {
                if (requestCode == REQUEST_CODE_PERMISSION) {
                    boolean granted = grantResult == PackageManager.PERMISSION_GRANTED;
                    Log.d(TAG, "Shizuku permission result: " + granted);
                    if (permissionCallback != null) {
                        permissionCallback.onPermissionResult(granted);
                    }
                }
            }
        };

    public static boolean isShizukuAvailable() {
        try {
            return Shizuku.pingBinder();
        } catch (Exception e) {
            Log.e(TAG, "Error checking Shizuku availability", e);
            return false;
        }
    }

    public static void executeShellCommand(String command, ShellCommandCallback callback) {
        new Thread(() -> {
            try {
                if (!isShizukuAvailable()) {
                    if (callback != null) {
                        callback.onResult("Shizuku not available");
                    }
                    return;
                }

                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                    if (callback != null) {
                        callback.onResult("Permission denied");
                    }
                    return;
                }

                Process process = Shizuku.newProcess(new String[]{"sh", "-c", command}, null, null);
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));

                StringBuilder output = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }

                while ((line = errorReader.readLine()) != null) {
                    output.append(line).append("\n");
                }

                process.waitFor();
                reader.close();
                errorReader.close();

                if (callback != null) {
                    callback.onResult(output.toString().trim());
                }
            } catch (Exception e) {
                Log.e(TAG, "Error executing shell command", e);
                if (callback != null) {
                    callback.onResult("Error: " + e.getMessage());
                }
            }
        }).start();
    }
}