package com.viqitos.tools.ui.permission;

public class PermissionInfo {
    public String name;
    public String displayName;
    public String description;
    public boolean isGranted;
    public boolean isDangerous;
    public String packageName; // 添加包名字段

    public PermissionInfo(String name, String displayName, String description, boolean isGranted, boolean isDangerous) {
        this.name = name;
        this.displayName = displayName;
        this.description = description;
        this.isGranted = isGranted;
        this.isDangerous = isDangerous;
    }
}
