package com.viqitos.tools.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;

import com.kongzue.dialogx.dialogs.InputDialog;
import com.kongzue.dialogx.dialogs.MessageDialog;
import com.kongzue.dialogx.dialogs.PopTip;
import com.kongzue.dialogx.dialogs.WaitDialog;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class CardVerificationManager {
    private static final String TAG = "CardVerificationManager";
    private static final String PREF_NAME = "CardVerification";
    private static final String KEY_CARD_CODE = "card_code";
    private static final String KEY_VERIFIED = "verified";
    private static final String API_URL = "http://120.26.83.1/card_api/check_card.php";

    private final Context context;
    private final SharedPreferences preferences;
    private final OkHttpClient httpClient;
    private final Handler mainHandler;
    private boolean isVerifying = false;
    private boolean verificationCompleted = false;

    public interface VerificationCallback {
        void onSuccess();
        void onError(String message);
    }

    public CardVerificationManager(Context context) {
        this.context = context.getApplicationContext();
        this.preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        this.mainHandler = new Handler(Looper.getMainLooper());

        this.httpClient = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();
    }

    public boolean isVerified() {
        return preferences.getBoolean(KEY_VERIFIED, false);
    }

    public String getSavedCardCode() {
        return preferences.getString(KEY_CARD_CODE, null);
    }

    public void saveCardVerification(String cardCode) {
        preferences.edit()
                .putString(KEY_CARD_CODE, cardCode)
                .putBoolean(KEY_VERIFIED, true)
                .apply();
    }

    public void clearVerification() {
        preferences.edit()
                .remove(KEY_CARD_CODE)
                .putBoolean(KEY_VERIFIED, false)
                .apply();
    }

    public void verifyCard(String cardCode, VerificationCallback callback) {
        try {
            String androidId = Settings.Secure.getString(
                    context.getContentResolver(),
                    Settings.Secure.ANDROID_ID
            );
            if (androidId == null) {
                androidId = "unknown_id";
            }
            String deviceCode = androidId + "_" + Build.BRAND + "_" + Build.MODEL;

            String appVersion;
            try {
                android.content.pm.PackageInfo packageInfo =
                        context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
                appVersion = packageInfo.versionName + " (" + packageInfo.versionCode + ")";
            } catch (Exception e) {
                appVersion = "unknown";
            }

            FormBody formBody = new FormBody.Builder()
                    .add("card", cardCode)
                    .add("device", deviceCode)
                    .add("app_version", appVersion)
                    .build();

            Request request = new Request.Builder()
                    .url(API_URL)
                    .post(formBody)
                    .build();

            httpClient.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "网络请求失败", e);
                    mainHandler.post(() -> {
                        if (callback != null) {
                            callback.onError("网络请求失败: " + e.getMessage());
                        }
                    });
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (!response.isSuccessful()) {
                        mainHandler.post(() -> {
                            if (callback != null) {
                                callback.onError("服务器返回错误: " + response.code());
                            }
                        });
                        return;
                    }

                    String responseBody = response.body().string();
                    mainHandler.post(() -> {
                        switch (responseBody) {
                            case "success":
                                saveCardVerification(cardCode);
                                if (callback != null) {
                                    callback.onSuccess();
                                }
                                break;
                            case "error:used_by_another":
                                if (callback != null) {
                                    callback.onError("卡密已被绑定其他设备！");
                                }
                                break;
                            case "error:not_found":
                                if (callback != null) {
                                    callback.onError("卡密无效！");
                                }
                                break;
                            case "error:missing_data":
                                if (callback != null) {
                                    callback.onError("参数缺失！");
                                }
                                break;
                            default:
                                if (callback != null) {
                                    callback.onError("验证失败: " + responseBody);
                                }
                                break;
                        }
                    });
                }
            });

        } catch (Exception e) {
            Log.e(TAG, "卡密验证异常", e);
            if (callback != null) {
                callback.onError("验证异常: " + e.getMessage());
            }
        }
    }

    public void showVerificationDialog(Runnable onVerificationComplete) {
        if (isVerifying) {
            Log.w(TAG, "验证正在进行中，忽略重复请求");
            return;
        }

        InputDialog inputDialog = InputDialog.show("卡密激活", "请输入您的卡密激活码\n\n⚠️ 必须验证卡密才能使用应用", "确定")
                .setInputHintText("请输入卡密")
                .setCancelButton("")
                .setCancelable(false);

        inputDialog.setOkButtonClickListener((dialog, v, inputStr) -> {
            if (inputStr == null || inputStr.trim().isEmpty()) {
                PopTip.show("⚠️ 请输入卡密后再点击确定");
                return false;
            }

            String cardCode = inputStr.trim();

            if (cardCode.isEmpty()) {
                PopTip.show("⚠️ 卡密不能为空");
                return false;
            }

            isVerifying = true;

            dialog.dismiss();
            WaitDialog.show("正在验证卡密...");

            verifyCard(cardCode, new VerificationCallback() {
                @Override
                public void onSuccess() {
                    isVerifying = false;
                    verificationCompleted = true;
                    WaitDialog.dismiss();
                    MessageDialog.show("激活成功", "卡密验证成功，欢迎使用 Viqitos Tools！", "确定")
                            .setCancelable(false)
                            .setOkButtonClickListener((d, view) -> {
                                if (onVerificationComplete != null) {
                                    onVerificationComplete.run();
                                }
                                return false;
                            });
                }

                @Override
                public void onError(String message) {
                    isVerifying = false;
                    WaitDialog.dismiss();
                    MessageDialog.show("激活失败", message + "\n\n请重新输入正确的卡密", "重试")
                            .setCancelable(false)
                            .setOkButtonClickListener((d, view) -> {
                                mainHandler.post(() -> showVerificationDialog(onVerificationComplete));
                                return false;
                            });
                }
            });

            return false;
        });
    }

    public void checkAndVerify(Runnable onVerificationComplete) {
        if (verificationCompleted) {
            Log.i(TAG, "验证已完成，直接执行回调");
            if (onVerificationComplete != null) {
                onVerificationComplete.run();
            }
            return;
        }

        if (isVerified()) {
            String savedCardCode = getSavedCardCode();
            if (savedCardCode != null && !savedCardCode.isEmpty()) {
                isVerifying = true;
                verifyCard(savedCardCode, new VerificationCallback() {
                    @Override
                    public void onSuccess() {
                        isVerifying = false;
                        verificationCompleted = true;
                        Log.i(TAG, "自动验证成功");
                        if (onVerificationComplete != null) {
                            onVerificationComplete.run();
                        }
                    }

                    @Override
                    public void onError(String message) {
                        isVerifying = false;
                        Log.e(TAG, "自动验证失败: " + message);
                        clearVerification();
                        showVerificationDialog(onVerificationComplete);
                    }
                });
            } else {
                showVerificationDialog(onVerificationComplete);
            }
        } else {
            showVerificationDialog(onVerificationComplete);
        }
    }

    public void destroy() {
        if (httpClient != null) {
            httpClient.dispatcher().executorService().shutdown();
        }
    }
}
