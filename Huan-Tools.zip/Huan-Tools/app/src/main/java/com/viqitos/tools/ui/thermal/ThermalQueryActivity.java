package com.viqitos.tools.ui.thermal;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.MaterialToolbar;
import com.kongzue.dialogx.dialogs.PopTip;
import com.kongzue.dialogx.dialogs.WaitDialog;
import com.viqitos.tools.R;
import com.viqitos.tools.utils.ShizukuHelper;
import java.util.ArrayList;
import java.util.List;

public class ThermalQueryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ThermalAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thermal_query);

        if (!ShizukuHelper.isShizukuAvailable()) {
            PopTip.show("需要Shizuku权限才能查询温度信息");
            finish();
            return;
        }

        setupViews();
        queryTemperature();
    }

    private void setupViews() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("温度查询");
        }

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ThermalAdapter(this);
        recyclerView.setAdapter(adapter);
    }

    private void queryTemperature() {
        WaitDialog.show("查询中...");

        String[] components = {
            "CPU",
            "GPU",
            "BATTER",
            "NPU",
            "TPU",
            "SOC",
            "SKIN",
            "CoolingDevice",
            "Current temperatures from HAL",
            "Cached temperatures",
            "POWER_AMPLIFIER",
        };

        List<TemperatureZone> temperatureZones = new ArrayList<>();
        final int[] completedQueries = { 0 };
        final int totalQueries = components.length;

        for (String component : components) {
            String command =
                "dumpsys thermalservice | grep '" + component + "'";
            ShizukuHelper.executeShellCommand(command, result -> {
                runOnUiThread(() -> {
                    if (!result.trim().isEmpty()) {
                        String[] lines = result.split(""); // 使用\\n来正确分割行
                        for (String line : lines) {
                            line = line.trim();
                            if (!line.isEmpty()) {
                                temperatureZones.add(
                                    new TemperatureZone(component, line)
                                );
                            }
                        }
                    }

                    completedQueries[0]++;
                    if (completedQueries[0] >= totalQueries) {
                        runOnUiThread(() -> {
                            adapter.updateData(temperatureZones);
                            WaitDialog.dismiss();
                        });
                    }
                });
            });
        }

        runOnUiThread(() -> {
            if (temperatureZones.isEmpty()) {
                PopTip.show("未获取到温度信息，请检查设备支持");
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public static class TemperatureZone {

        public String name;
        public String value;

        public TemperatureZone(String name, String value) {
            this.name = name;
            this.value = value;
        }
    }
}
