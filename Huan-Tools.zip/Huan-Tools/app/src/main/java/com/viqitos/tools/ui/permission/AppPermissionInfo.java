package com.viqitos.tools.ui.permission;

import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.List;

public class AppPermissionInfo {
    public String packageName;
    public String appName;
    public Drawable icon;
    public List<PermissionInfo> permissions = new ArrayList<>();

    public int getGrantedCount() {
        int count = 0;
        for (PermissionInfo permission : permissions) {
            if (permission.isGranted) {
                count++;
            }
        }
        return count;
    }

    public int getTotalCount() {
        return permissions.size();
    }
}
