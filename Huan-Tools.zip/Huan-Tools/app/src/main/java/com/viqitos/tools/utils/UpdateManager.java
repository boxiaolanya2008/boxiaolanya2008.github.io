package com.viqitos.tools.utils;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.kongzue.dialogx.dialogs.MessageDialog;
import com.kongzue.dialogx.dialogs.WaitDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class UpdateManager {
    private static final String TAG = "UpdateManager";
    private static final String PREF_NAME = "AppUpdatePrefs";
    private static final String KEY_LAST_UPDATE_CHECK = "last_update_check";
    private static final long UPDATE_CHECK_INTERVAL = 24 * 60 * 60 * 1000L;

    private final Context context;
    private final OkHttpClient httpClient;
    private final DownloadManager downloadManager;
    private final SharedPreferences preferences;
    private final Handler mainHandler;
    private final Handler backgroundHandler;

    private long downloadId = -1;
    private BroadcastReceiver downloadReceiver;
    private UpdateCallback updateCallback;
    private Runnable backgroundCheckRunnable;
    private boolean isBackgroundCheckEnabled = false;

    public static class UpdateInfo {
        public final String versionName;
        public final int versionCode;
        public final String updateInfo;
        public final String downloadUrl;
        public final boolean isForceUpdate;

        public UpdateInfo(String versionName, int versionCode, String updateInfo, 
                         String downloadUrl, boolean isForceUpdate) {
            this.versionName = versionName;
            this.versionCode = versionCode;
            this.updateInfo = updateInfo;
            this.downloadUrl = downloadUrl;
            this.isForceUpdate = isForceUpdate;
        }
    }

    public interface UpdateCallback {
        void onUpdateAvailable(UpdateInfo updateInfo);
        void onNoUpdate();
        void onError(String message);
        void onDownloadProgress(int progress);
        void onDownloadComplete(File file);
    }

    public UpdateManager(Context context) {
        this.context = context.getApplicationContext();
        this.preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.backgroundHandler = new Handler(Looper.getMainLooper());

        this.httpClient = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .build();

        this.downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        initBackgroundCheck();
    }

    public void setUpdateCallback(UpdateCallback callback) {
        this.updateCallback = callback;
    }

    public boolean shouldCheckUpdate() {
        long lastCheck = preferences.getLong(KEY_LAST_UPDATE_CHECK, 0);
        long now = System.currentTimeMillis();
        return now - lastCheck > UPDATE_CHECK_INTERVAL;
    }

    private void recordUpdateCheck() {
        preferences.edit()
                .putLong(KEY_LAST_UPDATE_CHECK, System.currentTimeMillis())
                .apply();
    }

    public void checkForUpdates() {
        checkForUpdates(false);
    }

    public void checkForUpdates(boolean showProgress) {
        if (showProgress) {
            WaitDialog.show("正在检查更新...");
        }
        checkServerUpdateControl(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "检查服务器更新控制失败", e);
                performUpdateCheck(showProgress);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    performUpdateCheck(showProgress);
                    return;
                }

                try {
                    String responseBody = response.body().string();
                    JSONObject json = new JSONObject(responseBody);
                    boolean success = json.optBoolean("success", false);

                    if (success) {
                        JSONObject data = json.optJSONObject("data");
                        String status = data != null ? data.optString("status", "NORMAL") : "NORMAL";
                        
                        Log.i(TAG, "服务器更新控制状态: " + status);

                        if ("DISABLED".equals(status)) {
                            mainHandler.post(() -> {
                                if (showProgress) {
                                    WaitDialog.dismiss();
                                }
                                Log.i(TAG, "服务器已禁止更新，跳过更新检查");
                                if (updateCallback != null) {
                                    updateCallback.onNoUpdate();
                                }
                            });
                            recordUpdateCheck();
                            return;
                        }
                    }

                    performUpdateCheck(showProgress);
                } catch (JSONException e) {
                    Log.e(TAG, "解析服务器更新控制状态失败", e);
                    performUpdateCheck(showProgress);
                }
            }
        });
    }

    private void checkServerUpdateControl(Callback callback) {
        Request request = new Request.Builder()
                .url("http://youhualan.xyz/admin_update_control.php")
                .get()
                .build();

        httpClient.newCall(request).enqueue(callback);
    }

    private void performUpdateCheck(boolean showProgress) {
        try {
            int currentVersionCode = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0)
                    .versionCode;

            String url = String.format(
                    "http://120.26.83.1/check_update.json",
                    context.getPackageName(),
                    currentVersionCode,
                    Build.MANUFACTURER,
                    Build.MODEL,
                    Build.VERSION.RELEASE
            );

            Request request = new Request.Builder()
                    .url(url)
                    .get()
                    .build();

            httpClient.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "检查更新失败", e);
                    mainHandler.post(() -> {
                        if (showProgress) {
                            WaitDialog.dismiss();
                        }
                        if (updateCallback != null) {
                            updateCallback.onError("检查更新失败: " + e.getMessage());
                        }
                    });
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (!response.isSuccessful()) {
                        mainHandler.post(() -> {
                            if (showProgress) {
                                WaitDialog.dismiss();
                            }
                            if (updateCallback != null) {
                                updateCallback.onError("服务器返回错误: " + response.code());
                            }
                        });
                        return;
                    }

                    try {
                        String responseBody = response.body().string();
                        JSONObject json = new JSONObject(responseBody);
                        boolean hasUpdate = json.optBoolean("has_update", false);

                        if (hasUpdate) {
                            int serverVersionCode = json.optInt("version_code", 0);

                            if (serverVersionCode > currentVersionCode) {
                                UpdateInfo updateInfo = new UpdateInfo(
                                        json.optString("version_name", ""),
                                        serverVersionCode,
                                        json.optString("update_info", ""),
                                        json.optString("download_url", ""),
                                        json.optBoolean("force_update", false)
                                );

                                mainHandler.post(() -> {
                                    if (showProgress) {
                                        WaitDialog.dismiss();
                                    }
                                    if (updateCallback != null) {
                                        updateCallback.onUpdateAvailable(updateInfo);
                                    }
                                });
                            } else {
                                mainHandler.post(() -> {
                                    if (showProgress) {
                                        WaitDialog.dismiss();
                                    }
                                    if (updateCallback != null) {
                                        updateCallback.onNoUpdate();
                                    }
                                });
                            }
                        } else {
                            mainHandler.post(() -> {
                                if (showProgress) {
                                    WaitDialog.dismiss();
                                }
                                if (updateCallback != null) {
                                    updateCallback.onNoUpdate();
                                }
                            });
                        }

                        recordUpdateCheck();
                    } catch (JSONException e) {
                        Log.e(TAG, "解析更新信息失败", e);
                        mainHandler.post(() -> {
                            if (showProgress) {
                                WaitDialog.dismiss();
                            }
                            if (updateCallback != null) {
                                updateCallback.onError("解析更新信息失败");
                            }
                        });
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "检查更新异常", e);
            if (showProgress) {
                WaitDialog.dismiss();
            }
            if (updateCallback != null) {
                updateCallback.onError("检查更新异常: " + e.getMessage());
            }
        }
    }

    public void showUpdateDialog(UpdateInfo updateInfo) {
        String message = "版本: " + updateInfo.versionName + "\n\n更新内容:\n" + updateInfo.updateInfo;
        if (updateInfo.isForceUpdate) {
            message += "\n\n⚠️ 这是一个强制更新版本，必须更新才能继续使用";
        }

        MessageDialog messageDialog = MessageDialog.show("发现新版本", message, "立即更新", updateInfo.isForceUpdate ? "" : "稍后再说")
                .setCancelable(!updateInfo.isForceUpdate);
        messageDialog.setOkButtonClickListener((dialog, v) -> {
            downloadUpdate(updateInfo.downloadUrl, updateInfo.versionName);
            return false;
        });
        if (!updateInfo.isForceUpdate) {
            messageDialog.setCancelButtonClickListener((dialog, v) -> {
                Log.i(TAG, "用户选择稍后更新");
                return false;
            });
        }
    }

    public void downloadUpdate(String downloadUrl, String versionName) {
        try {
            WaitDialog.show("正在准备下载...");
            registerDownloadReceiver();

            Uri uri = Uri.parse(downloadUrl);
            String fileName = "viqitos_update_v" + versionName + ".apk";

            DownloadManager.Request request = new DownloadManager.Request(uri);
            request.setTitle("正在下载更新");
            request.setDescription("Viqitos Tools 版本 " + versionName);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(true);

            downloadId = downloadManager.enqueue(request);
            Log.i(TAG, "开始下载更新: " + downloadUrl + ", 下载ID: " + downloadId);
            startProgressMonitoring();

        } catch (Exception e) {
            Log.e(TAG, "下载更新失败", e);
            WaitDialog.dismiss();
            MessageDialog.show("下载失败", "无法下载更新: " + e.getMessage(), "确定");
        }
    }

    private void registerDownloadReceiver() {
        unregisterDownloadReceiver();

        downloadReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                if (id == downloadId) {
                    handleDownloadComplete();
                }
            }
        };

        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        ContextCompat.registerReceiver(context, downloadReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    private void startProgressMonitoring() {
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                int progress = queryDownloadProgress();
                if (progress >= 0 && progress < 100) {
                    if (updateCallback != null) {
                        updateCallback.onDownloadProgress(progress);
                    }
                    mainHandler.postDelayed(this, 500);
                }
            }
        }, 500);
    }

    private int queryDownloadProgress() {
        try {
            DownloadManager.Query query = new DownloadManager.Query().setFilterById(downloadId);
            android.database.Cursor cursor = downloadManager.query(query);

            if (cursor != null && cursor.moveToFirst()) {
                int statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
                int bytesDownloadedIndex = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR);
                int bytesTotalIndex = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES);

                if (statusIndex != -1 && bytesDownloadedIndex != -1 && bytesTotalIndex != -1) {
                    int status = cursor.getInt(statusIndex);
                    long bytesDownloaded = cursor.getLong(bytesDownloadedIndex);
                    long bytesTotal = cursor.getLong(bytesTotalIndex);

                    cursor.close();

                    if (status == DownloadManager.STATUS_RUNNING && bytesTotal > 0) {
                        return (int) (bytesDownloaded * 100 / bytesTotal);
                    }
                }
                if (cursor != null && !cursor.isClosed()) {
                    cursor.close();
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "查询下载进度失败", e);
        }
        return -1;
    }

    private void handleDownloadComplete() {
        try {
            DownloadManager.Query query = new DownloadManager.Query().setFilterById(downloadId);
            android.database.Cursor cursor = downloadManager.query(query);

            if (cursor != null && cursor.moveToFirst()) {
                int statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
                int uriIndex = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI);

                if (statusIndex != -1 && uriIndex != -1) {
                    int status = cursor.getInt(statusIndex);
                    String localUri = cursor.getString(uriIndex);

                    cursor.close();

                    if (status == DownloadManager.STATUS_SUCCESSFUL) {
                        Log.i(TAG, "下载完成: " + localUri);
                        File file = new File(Uri.parse(localUri).getPath());
                        if (file.exists()) {
                            if (updateCallback != null) {
                                updateCallback.onDownloadComplete(file);
                            }
                            installApk(file);
                        }
                    } else if (status == DownloadManager.STATUS_FAILED) {
                        Log.e(TAG, "下载失败");
                        MessageDialog.show("下载失败", "更新包下载失败，请稍后重试", "确定");
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "处理下载完成失败", e);
        } finally {
            cleanup();
        }
    }

    private void unregisterDownloadReceiver() {
        if (downloadReceiver != null) {
            try {
                context.unregisterReceiver(downloadReceiver);
            } catch (Exception e) {
                Log.e(TAG, "注销下载广播接收器失败", e);
            }
            downloadReceiver = null;
        }
    }

    private void cleanup() {
        unregisterDownloadReceiver();
        downloadId = -1;
    }

    public void installApk(File file) {
        try {
            Log.i(TAG, "开始安装APK: " + file.getAbsolutePath());

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                String authority = context.getPackageName() + ".fileprovider";
                Uri uri = FileProvider.getUriForFile(context, authority, file);
                intent.setDataAndType(uri, "application/vnd.android.package-archive");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } else {
                intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
            }

            context.startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "安装APK失败", e);
            MessageDialog.show("安装失败", "无法安装更新: " + e.getMessage(), "确定");
        }
    }

    public void destroy() {
        stopBackgroundCheck();
        cleanup();
        if (httpClient != null) {
            httpClient.dispatcher().executorService().shutdown();
        }
    }

    private void initBackgroundCheck() {
        backgroundCheckRunnable = new Runnable() {
            @Override
            public void run() {
                if (isBackgroundCheckEnabled && shouldCheckUpdate()) {
                    Log.d(TAG, "后台检查更新被触发");
                    checkForUpdates(false);
                }
                if (isBackgroundCheckEnabled) {
                    backgroundHandler.postDelayed(this, UPDATE_CHECK_INTERVAL);
                }
            }
        };
    }

    public void startBackgroundCheck() {
        if (!isBackgroundCheckEnabled) {
            isBackgroundCheckEnabled = true;
            Log.i(TAG, "启动后台更新检查，间隔: " + (UPDATE_CHECK_INTERVAL / 1000 / 60 / 60) + "小时");
            backgroundHandler.post(backgroundCheckRunnable);
        }
    }

    public void stopBackgroundCheck() {
        if (isBackgroundCheckEnabled) {
            isBackgroundCheckEnabled = false;
            backgroundHandler.removeCallbacks(backgroundCheckRunnable);
            Log.i(TAG, "停止后台更新检查");
        }
    }

    public boolean isBackgroundCheckEnabled() {
        return isBackgroundCheckEnabled;
    }
}
