package com.viqitos.tools.ui.systemoptimize;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.viqitos.tools.R;
import com.viqitos.tools.utils.AnimationUtils;

import java.util.ArrayList;
import java.util.List;

public class OptimizationAdapter extends RecyclerView.Adapter<OptimizationAdapter.ViewHolder> {

    private List<SystemOptimizeActivity.OptimizationItem> allItems;
    private List<SystemOptimizeActivity.OptimizationItem> displayItems;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(SystemOptimizeActivity.OptimizationItem item);
    }

    public OptimizationAdapter(List<SystemOptimizeActivity.OptimizationItem> items, OnItemClickListener listener) {
        this.allItems = items;
        this.displayItems = new ArrayList<>(items);
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_optimization, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SystemOptimizeActivity.OptimizationItem item = displayItems.get(position);
        
        holder.txtTitle.setText(item.title);
        holder.txtDescription.setText(item.description);
        holder.txtCategory.setText(item.category);
        int categoryColor = getCategoryColor(item.category);
        holder.txtCategory.setBackgroundColor(categoryColor);

        holder.cardView.setOnClickListener(v -> {
            AnimationUtils.expressiveRipple(holder.cardView);
            if (listener != null) {
                listener.onItemClick(item);
            }
        });
        holder.itemView.setAlpha(0f);
        holder.itemView.setTranslationY(50f);
        holder.itemView.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(300)
                .setStartDelay(position * 50L)
                .start();
    }

    @Override
    public int getItemCount() {
        return displayItems.size();
    }

    public void filterByCategory(String category) {
        displayItems.clear();
        
        if (category == null || category.isEmpty()) {
            displayItems.addAll(allItems);
        } else {
            for (SystemOptimizeActivity.OptimizationItem item : allItems) {
                if (item.category.equals(category)) {
                    displayItems.add(item);
                }
            }
        }
        
        notifyDataSetChanged();
    }

    public void showAll() {
        displayItems.clear();
        displayItems.addAll(allItems);
        notifyDataSetChanged();
    }

    private int getCategoryColor(String category) {
        switch (category) {
            case "性能优化":
                return 0xFF4CAF50; // Green
            case "省电优化":
                return 0xFF2196F3; // Blue
            case "系统优化":
                return 0xFFFF9800; // Orange
            case "显示优化":
                return 0xFF9C27B0; // Purple
            default:
                return 0xFF757575; // Gray
        }
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        MaterialCardView cardView;
        TextView txtTitle;
        TextView txtDescription;
        TextView txtCategory;

        ViewHolder(View view) {
            super(view);
            cardView = view.findViewById(R.id.card_optimization);
            txtTitle = view.findViewById(R.id.txt_title);
            txtDescription = view.findViewById(R.id.txt_description);
            txtCategory = view.findViewById(R.id.txt_category);
        }
    }
}
