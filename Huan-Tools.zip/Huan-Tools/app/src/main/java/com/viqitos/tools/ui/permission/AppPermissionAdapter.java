package com.viqitos.tools.ui.permission;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.viqitos.tools.R;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AppPermissionAdapter extends RecyclerView.Adapter<AppPermissionAdapter.ViewHolder> {

    private final Context context;
    private final List<AppPermissionInfo> apps;
    private final PermissionAdapter.OnPermissionClickListener listener;
    private final Set<Integer> expandedPositions = new HashSet<>();

    public AppPermissionAdapter(Context context, List<AppPermissionInfo> apps, PermissionAdapter.OnPermissionClickListener listener) {
        this.context = context;
        this.apps = apps;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_permission_app, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AppPermissionInfo app = apps.get(position);
        boolean isExpanded = expandedPositions.contains(position);

        holder.appIcon.setImageDrawable(app.icon);
        holder.appName.setText(app.appName);
        holder.permissionCount.setText(app.getGrantedCount() + " / " + app.getTotalCount() + " 个权限已授予");
        holder.expandIcon.setRotation(isExpanded ? 180 : 0);
        holder.permissionsRecycler.setVisibility(isExpanded ? View.VISIBLE : View.GONE);
        holder.appHeader.setOnClickListener(v -> {
            if (isExpanded) {
                expandedPositions.remove(position);
            } else {
                expandedPositions.add(position);
            }
            notifyItemChanged(position);
        });
        if (isExpanded) {
            PermissionAdapter permissionAdapter = new PermissionAdapter(context, app.permissions, listener);
            holder.permissionsRecycler.setLayoutManager(new LinearLayoutManager(context));
            holder.permissionsRecycler.setAdapter(permissionAdapter);
        }
    }

    @Override
    public int getItemCount() {
        return apps.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout appHeader;
        ImageView appIcon;
        TextView appName;
        TextView permissionCount;
        ImageView expandIcon;
        RecyclerView permissionsRecycler;

        ViewHolder(View itemView) {
            super(itemView);
            appHeader = itemView.findViewById(R.id.app_header);
            appIcon = itemView.findViewById(R.id.app_icon);
            appName = itemView.findViewById(R.id.app_name);
            permissionCount = itemView.findViewById(R.id.permission_count);
            expandIcon = itemView.findViewById(R.id.expand_icon);
            permissionsRecycler = itemView.findViewById(R.id.permissions_recycler);
        }
    }
}
