package com.viqitos.tools.utils;

import static android.view.animation.AnimationUtils.loadAnimation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.OvershootInterpolator;
import androidx.interpolator.view.animation.FastOutSlowInInterpolator;
import com.google.android.material.button.MaterialButton;

public class AnimationUtils {

    private static final long DURATION_SHORT = 150;
    private static final long DURATION_MEDIUM = 300;
    private static final long DURATION_LONG = 500;
    private static final long DURATION_EXPRESSIVE = 450;

    private static final float OVERSHOOT_TENSION = 1.5f;

    public static void animateButtonPress(MaterialButton button) {
        button
            .animate()
            .scaleX(0.92f)
            .scaleY(0.92f)
            .setDuration(DURATION_SHORT)
            .setInterpolator(new FastOutSlowInInterpolator())
            .setListener(
                new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        button
                            .animate()
                            .scaleX(1.0f)
                            .scaleY(1.0f)
                            .setDuration(DURATION_MEDIUM)
                            .setInterpolator(
                                new OvershootInterpolator(OVERSHOOT_TENSION)
                            )
                            .setListener(null)
                            .start();
                    }
                }
            )
            .start();
    }

    public static void expressiveScaleIn(View view) {
        view.setScaleX(0.85f);
        view.setScaleY(0.85f);
        view.setAlpha(0f);
        view.setVisibility(View.VISIBLE);

        view
            .animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(DURATION_EXPRESSIVE)
            .setInterpolator(new OvershootInterpolator(OVERSHOOT_TENSION))
            .start();
    }

    public static void expressiveScaleOut(View view) {
        view
            .animate()
            .scaleX(0.85f)
            .scaleY(0.85f)
            .alpha(0f)
            .setDuration(DURATION_MEDIUM)
            .setInterpolator(new FastOutSlowInInterpolator())
            .setListener(
                new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        view.setVisibility(View.GONE);
                        view.setScaleX(1f);
                        view.setScaleY(1f);
                        view.setAlpha(1f);
                    }
                }
            )
            .start();
    }

    public static void expressiveBounce(View view) {
        PropertyValuesHolder scaleX = PropertyValuesHolder.ofFloat(
            View.SCALE_X,
            1f,
            1.1f,
            0.95f,
            1.02f,
            1f
        );
        PropertyValuesHolder scaleY = PropertyValuesHolder.ofFloat(
            View.SCALE_Y,
            1f,
            1.1f,
            0.95f,
            1.02f,
            1f
        );

        ObjectAnimator animator = ObjectAnimator.ofPropertyValuesHolder(
            view,
            scaleX,
            scaleY
        );
        animator.setDuration(DURATION_LONG);
        animator.setInterpolator(new FastOutSlowInInterpolator());
        animator.start();
    }

    public static void expressivePulse(View view) {
        view
            .animate()
            .scaleX(1.05f)
            .scaleY(1.05f)
            .setDuration(DURATION_MEDIUM)
            .setInterpolator(new FastOutSlowInInterpolator())
            .setListener(
                new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        view
                            .animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(DURATION_MEDIUM)
                            .setInterpolator(new OvershootInterpolator(0.5f))
                            .setListener(null)
                            .start();
                    }
                }
            )
            .start();
    }

    public static void fadeIn(View view) {
        view.setAlpha(0f);
        view.setVisibility(View.VISIBLE);
        view
            .animate()
            .alpha(1f)
            .setDuration(DURATION_MEDIUM)
            .setInterpolator(new FastOutSlowInInterpolator())
            .start();
    }

    public static void fadeOut(View view) {
        view
            .animate()
            .alpha(0f)
            .setDuration(DURATION_MEDIUM)
            .setInterpolator(new FastOutSlowInInterpolator())
            .setListener(
                new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        view.setVisibility(View.GONE);
                        view.setAlpha(1f);
                    }
                }
            )
            .start();
    }

    public static void playAnimation(
        View view,
        android.content.Context context,
        int animResource
    ) {
        Animation animation = loadAnimation(context, animResource);
        view.startAnimation(animation);
    }

    public static void slideInRight(View view) {
        view.setTranslationX(view.getWidth() > 0 ? view.getWidth() : 300);
        view.setAlpha(0f);
        view.setVisibility(View.VISIBLE);

        view
            .animate()
            .translationX(0)
            .alpha(1f)
            .setDuration(DURATION_EXPRESSIVE)
            .setInterpolator(new OvershootInterpolator(0.8f))
            .start();
    }

    public static void slideInLeft(View view) {
        view.setTranslationX(view.getWidth() > 0 ? -view.getWidth() : -300);
        view.setAlpha(0f);
        view.setVisibility(View.VISIBLE);

        view
            .animate()
            .translationX(0)
            .alpha(1f)
            .setDuration(DURATION_EXPRESSIVE)
            .setInterpolator(new OvershootInterpolator(0.8f))
            .start();
    }

    public static void slideInBottom(View view) {
        view.setTranslationY(view.getHeight() > 0 ? view.getHeight() : 200);
        view.setAlpha(0f);
        view.setVisibility(View.VISIBLE);

        view
            .animate()
            .translationY(0)
            .alpha(1f)
            .setDuration(DURATION_EXPRESSIVE)
            .setInterpolator(new OvershootInterpolator(0.8f))
            .start();
    }

    public static void slideOutLeft(View view) {
        view
            .animate()
            .translationX(-view.getWidth())
            .alpha(0f)
            .setDuration(DURATION_MEDIUM)
            .setInterpolator(new FastOutSlowInInterpolator())
            .setListener(
                new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        view.setVisibility(View.GONE);
                        view.setTranslationX(0);
                        view.setAlpha(1f);
                    }
                }
            )
            .start();
    }

    public static void expressiveRipple(View view) {
        view
            .animate()
            .scaleX(1.02f)
            .scaleY(1.02f)
            .setDuration(100)
            .setInterpolator(new FastOutSlowInInterpolator())
            .setListener(
                new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        view
                            .animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(200)
                            .setInterpolator(new FastOutSlowInInterpolator())
                            .setListener(null)
                            .start();
                    }
                }
            )
            .start();
    }

    public static void expressiveShake(View view) {
        PropertyValuesHolder translationX = PropertyValuesHolder.ofFloat(
            View.TRANSLATION_X,
            0f,
            -10f,
            10f,
            -8f,
            8f,
            -5f,
            5f,
            0f
        );

        ObjectAnimator animator = ObjectAnimator.ofPropertyValuesHolder(
            view,
            translationX
        );
        animator.setDuration(DURATION_LONG);
        animator.setInterpolator(new FastOutSlowInInterpolator());
        animator.start();
    }

    public static void expressiveRotateIn(View view) {
        view.setRotation(-15f);
        view.setScaleX(0.8f);
        view.setScaleY(0.8f);
        view.setAlpha(0f);
        view.setVisibility(View.VISIBLE);

        view
            .animate()
            .rotation(0f)
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(DURATION_EXPRESSIVE)
            .setInterpolator(new OvershootInterpolator(OVERSHOOT_TENSION))
            .start();
    }
}
