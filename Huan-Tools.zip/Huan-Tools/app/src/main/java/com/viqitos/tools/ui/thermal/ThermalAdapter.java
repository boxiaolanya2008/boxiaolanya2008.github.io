package com.viqitos.tools.ui.thermal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.viqitos.tools.R;
import java.util.ArrayList;
import java.util.List;

public class ThermalAdapter
    extends RecyclerView.Adapter<ThermalAdapter.ViewHolder> {

    private final Context context;
    private final List<ThermalQueryActivity.TemperatureZone> zones =
        new ArrayList<>();

    public ThermalAdapter(Context context) {
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(
        @NonNull ViewGroup parent,
        int viewType
    ) {
        View view = LayoutInflater.from(context).inflate(
            R.layout.item_thermal_zone,
            parent,
            false
        );
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ThermalQueryActivity.TemperatureZone zone = zones.get(position);
        holder.nameView.setText(zone.name);
        holder.typeView.setText("");
        holder.tempView.setText(zone.value);
    }

    @Override
    public int getItemCount() {
        return zones.size();
    }

    public void updateData(
        List<ThermalQueryActivity.TemperatureZone> newZones
    ) {
        zones.clear();
        zones.addAll(newZones);
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView nameView;
        TextView typeView;
        TextView tempView;

        ViewHolder(View itemView) {
            super(itemView);
            nameView = itemView.findViewById(R.id.zone_name);
            typeView = itemView.findViewById(R.id.zone_type);
            tempView = itemView.findViewById(R.id.zone_temp);
        }
    }
}
