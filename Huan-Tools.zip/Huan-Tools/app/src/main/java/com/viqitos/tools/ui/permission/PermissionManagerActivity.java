package com.viqitos.tools.ui.permission;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionGroupInfo;
import android.content.pm.PermissionInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.kongzue.dialogx.dialogs.MessageDialog;
import com.kongzue.dialogx.dialogs.PopTip;
import com.kongzue.dialogx.dialogs.WaitDialog;
import com.viqitos.tools.R;
import com.viqitos.tools.utils.ShizukuHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PermissionManagerActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private AppPermissionAdapter adapter;
    private EditText searchEdit;
    private TextView emptyView;
    private List<AppPermissionInfo> allApps = new ArrayList<>();
    private List<AppPermissionInfo> filteredApps = new ArrayList<>();
    private static final Map<String, String> PERMISSION_NAME_MAP = new HashMap<>();
    private static final Map<String, String> PERMISSION_DESC_MAP = new HashMap<>();

    static {
        PERMISSION_NAME_MAP.put("android.permission.CAMERA", "相机");
        PERMISSION_NAME_MAP.put("android.permission.READ_CONTACTS", "读取联系人");
        PERMISSION_NAME_MAP.put("android.permission.WRITE_CONTACTS", "写入联系人");
        PERMISSION_NAME_MAP.put("android.permission.GET_ACCOUNTS", "获取账户");
        PERMISSION_NAME_MAP.put("android.permission.ACCESS_FINE_LOCATION", "精确位置");
        PERMISSION_NAME_MAP.put("android.permission.ACCESS_COARSE_LOCATION", "大致位置");
        PERMISSION_NAME_MAP.put("android.permission.RECORD_AUDIO", "录音");
        PERMISSION_NAME_MAP.put("android.permission.READ_PHONE_STATE", "读取电话状态");
        PERMISSION_NAME_MAP.put("android.permission.CALL_PHONE", "拨打电话");
        PERMISSION_NAME_MAP.put("android.permission.READ_CALL_LOG", "读取通话记录");
        PERMISSION_NAME_MAP.put("android.permission.WRITE_CALL_LOG", "写入通话记录");
        PERMISSION_NAME_MAP.put("android.permission.SEND_SMS", "发送短信");
        PERMISSION_NAME_MAP.put("android.permission.RECEIVE_SMS", "接收短信");
        PERMISSION_NAME_MAP.put("android.permission.READ_SMS", "读取短信");
        PERMISSION_NAME_MAP.put("android.permission.READ_EXTERNAL_STORAGE", "读取存储");
        PERMISSION_NAME_MAP.put("android.permission.WRITE_EXTERNAL_STORAGE", "写入存储");
        PERMISSION_NAME_MAP.put("android.permission.BODY_SENSORS", "身体传感器");
        PERMISSION_NAME_MAP.put("android.permission.READ_CALENDAR", "读取日历");
        PERMISSION_NAME_MAP.put("android.permission.WRITE_CALENDAR", "写入日历");
        PERMISSION_NAME_MAP.put("android.permission.POST_NOTIFICATIONS", "通知");
        PERMISSION_NAME_MAP.put("android.permission.INTERNET", "网络访问");

        PERMISSION_DESC_MAP.put("android.permission.CAMERA", "允许应用使用相机拍照和录像");
        PERMISSION_DESC_MAP.put("android.permission.READ_CONTACTS", "允许应用读取联系人信息");
        PERMISSION_DESC_MAP.put("android.permission.WRITE_CONTACTS", "允许应用修改联系人信息");
        PERMISSION_DESC_MAP.put("android.permission.GET_ACCOUNTS", "允许应用访问账户列表");
        PERMISSION_DESC_MAP.put("android.permission.ACCESS_FINE_LOCATION", "允许应用获取精确位置");
        PERMISSION_DESC_MAP.put("android.permission.ACCESS_COARSE_LOCATION", "允许应用获取大致位置");
        PERMISSION_DESC_MAP.put("android.permission.RECORD_AUDIO", "允许应用录制音频");
        PERMISSION_DESC_MAP.put("android.permission.READ_PHONE_STATE", "允许应用读取手机状态");
        PERMISSION_DESC_MAP.put("android.permission.CALL_PHONE", "允许应用拨打电话");
        PERMISSION_DESC_MAP.put("android.permission.READ_CALL_LOG", "允许应用读取通话记录");
        PERMISSION_DESC_MAP.put("android.permission.WRITE_CALL_LOG", "允许应用写入通话记录");
        PERMISSION_DESC_MAP.put("android.permission.SEND_SMS", "允许应用发送短信");
        PERMISSION_DESC_MAP.put("android.permission.RECEIVE_SMS", "允许应用接收短信");
        PERMISSION_DESC_MAP.put("android.permission.READ_SMS", "允许应用读取短信");
        PERMISSION_DESC_MAP.put("android.permission.READ_EXTERNAL_STORAGE", "允许应用读取外部存储");
        PERMISSION_DESC_MAP.put("android.permission.WRITE_EXTERNAL_STORAGE", "允许应用写入外部存储");
        PERMISSION_DESC_MAP.put("android.permission.BODY_SENSORS", "允许应用访问传感器数据");
        PERMISSION_DESC_MAP.put("android.permission.READ_CALENDAR", "允许应用读取日历");
        PERMISSION_DESC_MAP.put("android.permission.WRITE_CALENDAR", "允许应用修改日历");
        PERMISSION_DESC_MAP.put("android.permission.POST_NOTIFICATIONS", "允许应用发送通知");
        PERMISSION_DESC_MAP.put("android.permission.INTERNET", "允许应用访问网络");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission_manager);
        if (!ShizukuHelper.isShizukuAvailable()) {
            PopTip.show("需要Shizuku权限才能使用权限管理功能");
            finish();
            return;
        }

        setupViews();
        loadPermissions();
    }

    private void setupViews() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("权限管理");
        }

        searchEdit = findViewById(R.id.search_edit);
        recyclerView = findViewById(R.id.recycler_view);
        emptyView = findViewById(R.id.empty_view);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new AppPermissionAdapter(this, filteredApps, this::onPermissionClick);
        recyclerView.setAdapter(adapter);

        searchEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterApps(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void loadPermissions() {
        WaitDialog.show("加载中...");
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            List<PackageInfo> packages = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS);

            allApps.clear();
            for (PackageInfo packageInfo : packages) {
                if (packageInfo.requestedPermissions != null && packageInfo.requestedPermissions.length > 0) {
                    ApplicationInfo appInfo = packageInfo.applicationInfo;

                    AppPermissionInfo info = new AppPermissionInfo();
                    info.packageName = packageInfo.packageName;
                    info.appName = appInfo.loadLabel(pm).toString();
                    info.icon = appInfo.loadIcon(pm);
                    for (int i = 0; i < packageInfo.requestedPermissions.length; i++) {
                        String permissionName = packageInfo.requestedPermissions[i];
                        boolean isGranted = (packageInfo.requestedPermissionsFlags[i] & PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0;

                        try {
                            PermissionInfo permInfo = pm.getPermissionInfo(permissionName, 0);
                            boolean isDangerous = permInfo.protectionLevel == PermissionInfo.PROTECTION_DANGEROUS;

                            String displayName = PERMISSION_NAME_MAP.get(permissionName);
                            if (displayName == null) {
                                displayName = permissionName.substring(permissionName.lastIndexOf(".") + 1);
                            }

                            String description = PERMISSION_DESC_MAP.get(permissionName);
                            if (description == null) {
                                description = permissionName;
                            }

                            com.viqitos.tools.ui.permission.PermissionInfo permission =
                                    new com.viqitos.tools.ui.permission.PermissionInfo(
                                            permissionName, displayName, description, isGranted, isDangerous);
                            permission.packageName = packageInfo.packageName;
                            info.permissions.add(permission);
                        } catch (PackageManager.NameNotFoundException e) {
                        }
                    }

                    if (!info.permissions.isEmpty()) {
                        allApps.add(info);
                    }
                }
            }
            Collections.sort(allApps, (a, b) -> a.appName.compareToIgnoreCase(b.appName));

            runOnUiThread(() -> {
                filteredApps.clear();
                filteredApps.addAll(allApps);
                adapter.notifyDataSetChanged();
                updateEmptyView();
                WaitDialog.dismiss();
            });
        }).start();
    }

    private void filterApps(String query) {
        filteredApps.clear();
        if (query.isEmpty()) {
            filteredApps.addAll(allApps);
        } else {
            String lowerQuery = query.toLowerCase();
            for (AppPermissionInfo app : allApps) {
                boolean match = app.appName.toLowerCase().contains(lowerQuery) ||
                               app.packageName.toLowerCase().contains(lowerQuery);

                if (!match) {
                    for (com.viqitos.tools.ui.permission.PermissionInfo permission : app.permissions) {
                        if (permission.displayName.toLowerCase().contains(lowerQuery) ||
                            permission.name.toLowerCase().contains(lowerQuery)) {
                            match = true;
                            break;
                        }
                    }
                }

                if (match) {
                    filteredApps.add(app);
                }
            }
        }
        adapter.notifyDataSetChanged();
        updateEmptyView();
    }

    private void updateEmptyView() {
        if (filteredApps.isEmpty()) {
            emptyView.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            emptyView.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void onPermissionClick(com.viqitos.tools.ui.permission.PermissionInfo permissionInfo) {
        String message = "权限名称: " + permissionInfo.displayName + "\n" +
                        "完整路径: " + permissionInfo.name + "\n" +
                        "描述: " + permissionInfo.description + "\n" +
                        "状态: " + (permissionInfo.isGranted ? "已授予" : "未授予") + "\n" +
                        "类型: " + (permissionInfo.isDangerous ? "危险权限" : "普通权限");
        if (permissionInfo.isDangerous) {
            String[] actions = permissionInfo.isGranted ?
                    new String[]{"撤销权限 (pm)", "撤销权限 (appops)", "取消"} :
                    new String[]{"授予权限 (pm)", "授予权限 (appops)", "取消"};

            com.kongzue.dialogx.dialogs.BottomMenu.show(actions)
                .setTitle("权限详情\n\n" + message)
                .setOnMenuItemClickListener((dialog, text, index) -> {
                    if (index == 2) return false;

                    boolean useAppOps = (index == 1);
                    boolean grant = !permissionInfo.isGranted;

                    modifyPermission(permissionInfo, grant, useAppOps);
                    return false;
                });
        } else {
            MessageDialog.show("权限详情", message + "\n\n注意: 普通权限无法修改。", "确定");
        }
    }

    private void modifyPermission(com.viqitos.tools.ui.permission.PermissionInfo permissionInfo, boolean grant, boolean useAppOps) {
        String action = grant ? "授予" : "撤销";
        String method = useAppOps ? "appops" : "pm";

        MessageDialog.show("确认操作",
                "确定要" + action + "权限吗？\n\n" +
                "应用: " + permissionInfo.packageName + "\n" +
                "权限: " + permissionInfo.displayName + "\n" +
                "方法: " + method,
                "确定", "取消"
        ).setOkButtonClickListener((dialog, v) -> {
            WaitDialog.show("正在" + action + "权限...");

            String command;
            if (useAppOps) {
                String permOp = convertPermissionToOp(permissionInfo.name);
                if (permOp != null) {
                    command = "appops set " + permissionInfo.packageName + " " + permOp + " " + (grant ? "allow" : "deny");
                } else {
                    runOnUiThread(() -> {
                        WaitDialog.dismiss();
                        PopTip.show("该权限不支持 appops 修改");
                    });
                    return false;
                }
            } else {
                if (grant) {
                    command = "pm grant " + permissionInfo.packageName + " " + permissionInfo.name;
                } else {
                    command = "pm revoke " + permissionInfo.packageName + " " + permissionInfo.name;
                }
            }

            ShizukuHelper.executeShellCommand(command, result -> {
                runOnUiThread(() -> {
                    WaitDialog.dismiss();
                    if (result.toLowerCase().contains("success") || result.isEmpty()) {
                        PopTip.show(action + "成功");
                        loadPermissions();
                    } else if (result.toLowerCase().contains("not granted") || result.toLowerCase().contains("not requested")) {
                        PopTip.show("该权限未在清单中声明");
                    } else {
                        PopTip.show(action + "失败: " + result);
                    }
                });
            });
            return false;
        });
    }

    private String convertPermissionToOp(String permission) {
        switch (permission) {
            case "android.permission.CAMERA":
                return "CAMERA";
            case "android.permission.RECORD_AUDIO":
                return "RECORD_AUDIO";
            case "android.permission.ACCESS_FINE_LOCATION":
            case "android.permission.ACCESS_COARSE_LOCATION":
                return "COARSE_LOCATION";
            case "android.permission.READ_CONTACTS":
                return "READ_CONTACTS";
            case "android.permission.WRITE_CONTACTS":
                return "WRITE_CONTACTS";
            case "android.permission.READ_CALL_LOG":
                return "READ_CALL_LOG";
            case "android.permission.WRITE_CALL_LOG":
                return "WRITE_CALL_LOG";
            case "android.permission.READ_CALENDAR":
                return "READ_CALENDAR";
            case "android.permission.WRITE_CALENDAR":
                return "WRITE_CALENDAR";
            case "android.permission.READ_SMS":
                return "READ_SMS";
            case "android.permission.SEND_SMS":
                return "SEND_SMS";
            case "android.permission.READ_PHONE_STATE":
                return "READ_PHONE_STATE";
            case "android.permission.CALL_PHONE":
                return "CALL_PHONE";
            default:
                return null;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
